# BrokeBase — Architecture

## Overview

BrokeBase is a single-page application (SPA) built on React + TypeScript.
In demo mode, all state is managed client-side with Zustand and pre-populated
with synthetic data. The architecture is designed to support a backend API
in a future phase without requiring frontend rewrites.

## Frontend Architecture

```
src/
├── components/
│   ├── ui/           # Primitive components (Button, Card, Input, etc.)
│   ├── layout/       # AppLayout — sidebar + header shell
│   ├── navigation/   # Navbar (landing), Sidebar, AppHeader, CommandPalette
│   └── common/       # ErrorBoundary, EmptyState, ConfidenceBadge, EntityTypeBadge
├── pages/            # Route-level components (one per route)
├── hooks/            # useToast (global notification system)
├── lib/
│   ├── utils.ts      # Pure utility functions (cn, formatDate, isValidUrl, etc.)
│   └── store.ts      # Zustand global state
├── types/            # TypeScript domain models
├── data/mock.ts      # Synthetic demo data (clearly labeled)
├── styles/globals.css # Design tokens + global CSS
└── tests/            # Vitest unit tests + security tests
```

## State Management

Zustand is used for global application state. The store holds:
- Demo mode flag
- Theme (light/dark)
- All domain entities: investigations, entities, sources, evidence, timeline, relationships
- UI state: commandPaletteOpen, sidebarOpen, activeInvestigationId

No server state is used in demo mode. TanStack Query is available for
future API integration.

## Routing

React Router v6 with two layout regions:
1. `/` — Landing page with floating navbar
2. `/app/*` — Application workspace with sidebar + header shell

## Component Design

- Primitive components are in `src/components/ui/` and wrap Radix UI primitives
- They accept standard HTML props plus a small set of typed variants
- All components are typed with TypeScript strict mode
- No `any` types in production code

## Design System

CSS custom properties define the design tokens (colors, radii, etc.).
Tailwind CSS v4 consumes these. The palette is black/white/grey with
controlled use of status colors (green=verified, amber=warning, red=error).

## Security Model (Frontend)

1. **Input sanitization** — `sanitizeSearchQuery()` strips XSS vectors from search
2. **URL validation** — `isValidUrl()` enforces https/http; blocks javascript:, data:, file:
3. **SSRF prevention** — Source URL input blocks private IP ranges (RFC 1918, loopback, link-local)
4. **No dangerouslySetInnerHTML** — All content rendered via React's safe APIs
5. **TypeScript strict** — Prevents type confusion and null dereference bugs
6. **ErrorBoundary** — Catches runtime errors without exposing internals to UI

## Future Backend Integration

The architecture is designed for easy backend addition:

1. Create `src/services/api.ts` — centralised API client with auth, retry, error normalization
2. Replace Zustand mock data with TanStack Query hooks
3. Add Zod validation for API response parsing
4. Backend: Fastify + TypeScript + Prisma + PostgreSQL (see SECURITY.md for controls)

## Provider Architecture

OSINT data sources are abstracted via a provider interface pattern:

```typescript
interface SearchProvider {
  search(query: string): Promise<SearchResult[]>
}

interface EntityProvider {
  resolve(id: string, type: EntityType): Promise<Entity>
}
```

This allows plugging in different public data sources without
changing the frontend logic.
