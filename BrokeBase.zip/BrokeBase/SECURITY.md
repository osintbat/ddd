# BrokeBase — Security Checklist

This document enumerates security controls for BrokeBase.
Each control includes category, risk, mitigation, implementation location, and status.

Status legend: PASS | FAIL | TODO | N/A

---

## 1. XSS (Cross-Site Scripting)

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 1 | Reflected XSS via search input | High | sanitizeSearchQuery() strips < > ' " | lib/utils.ts | PASS |
| 2 | Stored XSS in entity names | High | React escapes all string output | All components | PASS |
| 3 | DOM XSS via URL hash | High | No innerHTML usage; React Router handles routing | App.tsx | PASS |
| 4 | dangerouslySetInnerHTML usage | Critical | Not used anywhere in codebase | All components | PASS |
| 5 | XSS via evidence snippets | High | Rendered as text nodes via React | EvidencePage.tsx | PASS |
| 6 | SVG injection | Medium | No user-controlled SVG rendering | RelationshipsPage | PASS |
| 7 | Markdown injection | Medium | No markdown renderer; plain text only | All pages | PASS |
| 8 | HTML sanitization for rich text | High | No rich text input | N/A | N/A |

## 2. Input Validation

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 9 | Search query length limit | Medium | Max 512 chars enforced | sanitizeSearchQuery() | PASS |
| 10 | Entity name max length | Medium | maxLength=300 on inputs | EntitiesPage | PASS |
| 11 | Description max length | Medium | maxLength=1000 on textareas | All forms | PASS |
| 12 | URL format validation | High | isValidUrl() enforces https/http | lib/utils.ts | PASS |
| 13 | URL protocol allowlist | Critical | Blocks javascript:, data:, file:, ftp: | isValidUrl() | PASS |
| 14 | Date input validation | Low | HTML date input enforces format | TimelinePage | PASS |
| 15 | Select/enum validation | Medium | TypeScript types + Radix Select | All forms | PASS |
| 16 | Snippet length limit | Medium | Max 500 chars on evidence snippets | EvidencePage | PASS |
| 17 | Report content limits | Medium | Max 2000 chars per field | ReportsPage | PASS |

## 3. SSRF (Server-Side Request Forgery)

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 18 | Private IP blocking in source URLs | Critical | Regex blocks RFC 1918 ranges | SourcesPage, EvidencePage | PASS |
| 19 | Localhost blocking | Critical | Blocks 127.x, localhost | isPrivateIp() | PASS |
| 20 | Loopback IPv6 blocking | High | Blocks ::1 | isPrivateIp() | PASS |
| 21 | Link-local blocking | High | Blocks 169.254.x.x | isPrivateIp() | PASS |
| 22 | Cloud metadata endpoint protection | High | Private IP block covers 169.254.169.254 | isPrivateIp() | PASS |
| 23 | Protocol restriction | High | Only https/http allowed | isValidUrl() | PASS |

## 4. SQL Injection

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 24 | SQL injection via search | Critical | No SQL in frontend; Prisma ORM for backend | lib/utils.ts | N/A (frontend demo) |
| 25 | Parameterized queries | Critical | Prisma uses parameterized queries | Backend (future) | TODO |
| 26 | No string-concatenated SQL | Critical | Architecture forbids raw SQL | Backend pattern | TODO |
| 27 | Second-order injection | High | Prisma prevents this by default | Backend (future) | TODO |

## 5. Authentication & Session Security

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 28 | Password hashing algorithm | Critical | Argon2id planned for backend | Backend (future) | TODO |
| 29 | No plaintext passwords | Critical | N/A in demo; Argon2id in backend | Backend (future) | TODO |
| 30 | Session rotation on login | High | Backend (future) | Backend (future) | TODO |
| 31 | Session expiry | High | Backend (future) | Backend (future) | TODO |
| 32 | Secure, HttpOnly, SameSite cookies | Critical | Backend (future) | Backend (future) | TODO |
| 33 | Brute force protection | High | Rate limiting + lockout (backend) | Backend (future) | TODO |
| 34 | MFA-ready architecture | Medium | Architecture supports MFA | ARCHITECTURE.md | TODO |
| 35 | Account enumeration prevention | Medium | Generic error messages | Backend (future) | TODO |

## 6. Authorization

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 36 | Server-side authorization | Critical | All checks server-side (backend) | Backend (future) | TODO |
| 37 | IDOR prevention | High | Resource ownership checks | Backend (future) | TODO |
| 38 | BOLA prevention | High | Authorization middleware | Backend (future) | TODO |
| 39 | Privilege escalation | High | Role-based access | Backend (future) | TODO |
| 40 | Frontend auth is UX only | High | Documented: server decides | ARCHITECTURE.md | PASS |

## 7. CSRF

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 41 | CSRF tokens for state-changing ops | High | Backend (future) with Fastify | Backend (future) | TODO |
| 42 | SameSite cookie attribute | High | SameSite=Strict on session cookie | Backend (future) | TODO |
| 43 | Origin validation | Medium | CORS allowlist | Backend (future) | TODO |

## 8. Security Headers

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 44 | Content-Security-Policy | High | Backend / deployment config | Backend (future) | TODO |
| 45 | X-Content-Type-Options: nosniff | Medium | Backend header | Backend (future) | TODO |
| 46 | X-Frame-Options via CSP | Medium | frame-ancestors 'none' in CSP | Backend (future) | TODO |
| 47 | Referrer-Policy | Low | strict-origin-when-cross-origin | Backend (future) | TODO |
| 48 | Permissions-Policy | Low | Disable unused browser features | Backend (future) | TODO |
| 49 | HSTS | High | max-age=31536000; includeSubDomains | Backend (future) | TODO |
| 50 | Cross-Origin-Opener-Policy | Medium | same-origin | Backend (future) | TODO |
| 51 | Cross-Origin-Resource-Policy | Medium | same-origin | Backend (future) | TODO |
| 52 | Cross-Origin-Embedder-Policy | Medium | require-corp | Backend (future) | TODO |

## 9. Clickjacking

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 53 | Frame embedding prevention | High | CSP frame-ancestors 'none' | Backend (future) | TODO |
| 54 | X-Frame-Options legacy support | Medium | DENY header | Backend (future) | TODO |

## 10. Open Redirect

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 55 | Open redirect via URL params | High | No redirect-by-param logic | Codebase | PASS |
| 56 | External links use rel=noopener | Medium | All external <a> tags have noopener noreferrer | Landing/pages | PASS |

## 11. Path Traversal

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 57 | Path traversal in file ops | High | No file ops in frontend | N/A | N/A |
| 58 | Path traversal in backend | Critical | No user-controlled paths; fixed routes | Backend (future) | TODO |
| 59 | Null byte injection | High | isValidUrl rejects non-URL strings | lib/utils.ts | PASS |
| 60 | Double encoding bypass | High | URL parser handles encoding | isValidUrl() | PASS |

## 12. File Upload Security

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 61 | No file uploads in v1 | High | Feature not implemented | N/A | N/A |
| 62 | File type validation (future) | High | MIME type + extension check | Backend (future) | TODO |
| 63 | Upload size limits (future) | High | Max size enforcement | Backend (future) | TODO |
| 64 | Zip bomb prevention (future) | Medium | Decompression limits | Backend (future) | TODO |
| 65 | Executable upload prevention | Critical | Allowlist of safe extensions | Backend (future) | TODO |
| 66 | User-supplied filename (future) | High | Never use user-supplied filename | Backend (future) | TODO |

## 13. Dependency Security

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 67 | npm audit in CI | High | `npm run security` script | package.json | PASS |
| 68 | Lockfile present | High | package-lock.json committed | Root | PASS |
| 69 | Minimal dependencies | Medium | Only necessary packages | package.json | PASS |
| 70 | Pinned major versions | Medium | package.json uses ^ for minor | package.json | PASS |
| 71 | No deprecated packages | Medium | Regular audit runs | CI | TODO |

## 14. Secrets Management

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 72 | No secrets in source code | Critical | No credentials in codebase | Codebase | PASS |
| 73 | .env.example provided | Medium | Template without real values | Root | PASS |
| 74 | .gitignore covers .env | High | .gitignore includes .env | .gitignore | PASS |
| 75 | No secrets in logs | High | No PII/secrets logged | Codebase | PASS |
| 76 | No secrets in frontend bundle | Critical | No API keys in client code | src/ | PASS |

## 15. Error Handling

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 77 | No stack traces in UI | High | ErrorBoundary shows generic message + error ID | ErrorBoundary | PASS |
| 78 | Generic error messages | High | No internal details exposed | All components | PASS |
| 79 | Error reference IDs | Medium | Random ID for correlation | ErrorBoundary | PASS |
| 80 | Backend error filtering | High | Never return DB errors to client | Backend (future) | TODO |

## 16. Rate Limiting

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 81 | Search rate limiting | Medium | Backend middleware | Backend (future) | TODO |
| 82 | API rate limiting | High | Fastify rate-limit plugin | Backend (future) | TODO |
| 83 | Auth endpoint rate limiting | Critical | Strict limits + lockout | Backend (future) | TODO |
| 84 | Report generation limiting | Medium | Expensive operation protection | Backend (future) | TODO |

## 17. CORS

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 85 | CORS allowlist | High | No wildcard with credentials | Backend (future) | TODO |
| 86 | No Access-Control-Allow-Origin: * with credentials | Critical | Allowlist-based | Backend (future) | TODO |
| 87 | Preflight handling | Medium | Fastify CORS plugin | Backend (future) | TODO |

## 18. Cookie Security

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 88 | HttpOnly flag | High | Prevents JS access to session | Backend (future) | TODO |
| 89 | Secure flag | High | HTTPS-only cookies | Backend (future) | TODO |
| 90 | SameSite=Strict | High | CSRF mitigation | Backend (future) | TODO |
| 91 | Domain scoping | Medium | Minimal domain scope | Backend (future) | TODO |
| 92 | Path scoping | Low | /api path scope | Backend (future) | TODO |

## 19. Logging & Audit

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 93 | Structured logging | Medium | Pino/Winston with JSON | Backend (future) | TODO |
| 94 | No PII in logs | High | Log only IDs, not data | Backend (future) | TODO |
| 95 | No secrets in logs | Critical | Explicit exclusion | Backend (future) | TODO |
| 96 | Audit log for investigations | Medium | AuditLog model in schema | Backend (future) | TODO |
| 97 | Audit log for entity changes | Medium | AuditLog model | Backend (future) | TODO |
| 98 | Log injection prevention | Medium | Structured logging prevents | Backend (future) | TODO |
| 99 | Audit log integrity | High | Append-only audit table | Backend (future) | TODO |

## 20. Privacy & Data Minimization

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 100 | Data minimization principle | High | Collect only necessary fields | types/index.ts | PASS |
| 101 | No unnecessary PII | High | No SSN, DOB, biometric fields | types/index.ts | PASS |
| 102 | Demo data is synthetic | Critical | All demo data is fictional | data/mock.ts | PASS |
| 103 | Data retention controls | Medium | Delete flows implemented | All pages | PASS |
| 104 | Evidence snippet limits | Medium | Max 500 chars | EvidencePage | PASS |
| 105 | Export privacy controls | Medium | Future feature | Backend (future) | TODO |

## 21. Transport Security

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 106 | HTTPS enforcement | Critical | HSTS + redirect from HTTP | Backend/infra | TODO |
| 107 | TLS 1.2+ only | High | Server config | Infra | TODO |
| 108 | Strong cipher suites | High | TLS config | Infra | TODO |
| 109 | Certificate validation | Critical | Standard TLS | Infra | N/A |

## 22. Prototype Pollution

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 110 | Prototype pollution via JSON | High | Avoid Object.assign with user data | lib/store.ts | PASS |
| 111 | Deep merge safety | Medium | No deep merge with user input | Codebase | PASS |
| 112 | Zustand state pollution | Medium | Typed state prevents | lib/store.ts | PASS |

## 23. ReDoS

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 113 | Regex complexity in validation | Medium | Simple, bounded regexes used | lib/utils.ts | PASS |
| 114 | Search input length limit | Medium | 512 char max prevents long inputs | sanitizeSearchQuery | PASS |
| 115 | Private IP regex safety | Low | Fixed patterns with no catastrophic backtracking | isPrivateIp() | PASS |

## 24. Browser Security

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 116 | Subresource integrity | Medium | Font from Google Fonts (external CDN) | index.html | TODO |
| 117 | Third-party script safety | High | No third-party scripts in app | index.html | PASS |
| 118 | LocalStorage sensitive data | High | No sensitive data in localStorage | Codebase | PASS |
| 119 | sessionStorage sensitive data | High | No sensitive data in sessionStorage | Codebase | PASS |
| 120 | Skip-to-content link | Low | Accessibility + security | index.html | PASS |

## 25. Command Injection

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 121 | No shell execution | Critical | Frontend only; no exec calls | N/A | N/A |
| 122 | Backend command injection | Critical | No user input to shell (backend) | Backend (future) | TODO |

## 26. Template Injection

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 123 | SSTI via report templates | High | No template engine; plain string | ReportsPage | PASS |
| 124 | Expression injection | High | No eval-based rendering | Codebase | PASS |

## 27. Race Conditions

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 125 | TOCTOU in backend | Medium | Database transactions | Backend (future) | TODO |
| 126 | Concurrent investigation modification | Medium | Optimistic concurrency | Backend (future) | TODO |

## 28. Insecure Direct Object Reference (IDOR)

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 127 | Entity ID enumeration | High | Server-side ownership check | Backend (future) | TODO |
| 128 | Investigation access control | High | User-scoped queries | Backend (future) | TODO |
| 129 | UUIDs vs sequential IDs | Medium | generateId() produces non-sequential | lib/utils.ts | PASS |

## 29. API Security

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 130 | API versioning | Low | /api/v1/ prefix | Backend (future) | TODO |
| 131 | Schema validation | High | Zod on all inputs | Backend (future) | TODO |
| 132 | Pagination | Medium | Max page size enforced | Backend (future) | TODO |
| 133 | Response size limits | Medium | Fastify body limits | Backend (future) | TODO |
| 134 | HTTP method restrictions | Medium | Only GET/POST/PUT/DELETE | Backend (future) | TODO |
| 135 | TRACE disabled | Low | Server config | Backend (future) | TODO |

## 30. Infrastructure & CI/CD

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 136 | Git secret scanning | High | .gitignore covers sensitive files | .gitignore | PASS |
| 137 | Dependency scanning in CI | High | npm audit in pipeline | package.json scripts | PASS |
| 138 | Non-root Docker user | High | Docker (future) | Docker (future) | TODO |
| 139 | Minimal base image | Medium | Docker (future) | Docker (future) | TODO |
| 140 | Environment isolation | High | .env.example only | Root | PASS |
| 141 | Production config separation | High | No debug mode in prod build | vite.config.ts | PASS |
| 142 | Source map exposure | Medium | No source maps in prod by default | Vite default | PASS |

## 31. Accessibility & Security Intersection

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 143 | ARIA roles on dialogs | Low | Radix Dialog handles ARIA | ui/dialog.tsx | PASS |
| 144 | Focus trap in modals | Medium | Radix handles focus trapping | ui/dialog.tsx | PASS |
| 145 | Alert role on errors | Low | role="alert" on error notices | Components | PASS |
| 146 | Keyboard navigation | Medium | All interactive elements keyboard-accessible | Components | PASS |

## 32. Miscellaneous Controls

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 147 | No console.log in production | Low | ESLint warns on console.log | .eslintrc.cjs | PASS |
| 148 | TypeScript strict mode | High | Prevents class of runtime bugs | tsconfig.json | PASS |
| 149 | No eval() usage | Critical | Not used anywhere | Codebase | PASS |
| 150 | No innerHTML assignment | High | Not used anywhere | Codebase | PASS |
| 151 | Graceful error handling | Medium | ErrorBoundary at app level | App.tsx | PASS |
| 152 | No hardcoded credentials | Critical | No credentials in source | Codebase | PASS |
| 153 | Reduced motion support | Low | CSS prefers-reduced-motion | styles/globals.css | PASS |
| 154 | External links rel=noopener | Medium | Prevents tab-napping | Landing/Pages | PASS |
| 155 | No sensitive data in URL params | High | IDs only in URLs, no data | router | PASS |

## 33. Host Header & Request Security

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 156 | Host header injection | High | Validate expected hosts | Backend (future) | TODO |
| 157 | IP spoofing via Forwarded headers | Medium | Trust only configured proxy | Backend (future) | TODO |
| 158 | Request timeout | Medium | Fastify request timeout | Backend (future) | TODO |
| 159 | Body size limits | High | Fastify body limit | Backend (future) | TODO |
| 160 | Keep-alive abuse | Low | Server config | Backend (future) | TODO |

## 34. Cache Security

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 161 | Cache-Control on sensitive routes | High | no-store on API responses | Backend (future) | TODO |
| 162 | Cache poisoning prevention | High | Vary headers + cache keys | Backend (future) | TODO |
| 163 | Cache deception | Medium | Auth checks bypass cache | Backend (future) | TODO |

## 35. Data Exposure

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 164 | Sensitive data in API responses | High | Field-level authorization | Backend (future) | TODO |
| 165 | Debug mode exposure | High | NODE_ENV=production enforced | Backend (future) | TODO |
| 166 | Verbose errors to client | High | Generic error messages only | ErrorBoundary | PASS |
| 167 | Internal paths in errors | High | Error IDs, not paths | ErrorBoundary | PASS |

## 36. Database Security

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 168 | Least privilege DB user | High | Read/write only, no DDL | Backend (future) | TODO |
| 169 | DB not internet-exposed | Critical | Private network only | Infra | TODO |
| 170 | DB connection encryption | High | SSL required | Backend (future) | TODO |
| 171 | Query timeouts | Medium | Prisma query timeout | Backend (future) | TODO |
| 172 | Connection pooling limits | Medium | PgBouncer or Prisma pool | Backend (future) | TODO |
| 173 | Backup encryption | High | Encrypted backups | Infra | TODO |

## 37. Session Management

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 174 | Session fixation prevention | High | New session on login | Backend (future) | TODO |
| 175 | Session invalidation on logout | High | Server-side session destroy | Backend (future) | TODO |
| 176 | Concurrent session limits | Low | Configurable | Backend (future) | TODO |

## 38. Password & Credential Policy

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 177 | Minimum password length | High | 12 chars minimum | Backend (future) | TODO |
| 178 | Password breach checking | Medium | HaveIBeenPwned API | Backend (future) | TODO |
| 179 | No password hints stored | Medium | None stored | Backend (future) | TODO |
| 180 | Secure password reset | High | Time-limited tokens | Backend (future) | TODO |

## 39. Supply Chain

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 181 | Lockfile integrity | High | package-lock.json | Root | PASS |
| 182 | Typosquatting risk | Medium | Verify package names | Manual review | PASS |
| 183 | Package provenance | Low | npm provenance (future) | CI | TODO |
| 184 | SBOM generation | Low | Future | CI | TODO |

## 40. Monitoring & Incident Response

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 185 | Security event logging | High | Backend audit logs | Backend (future) | TODO |
| 186 | Anomaly detection | Medium | Rate limit alerts | Backend (future) | TODO |
| 187 | Incident response plan | High | Document (future) | Docs | TODO |
| 188 | Alerting on auth failures | High | Logging + alerting | Backend (future) | TODO |

## 41. Testing

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 189 | Unit tests for security utils | High | 44 tests covering security fns | src/tests/ | PASS |
| 190 | URL validation tests | High | isValidUrl test suite | security.test.ts | PASS |
| 191 | SSRF prevention tests | High | isPrivateIp test suite | security.test.ts | PASS |
| 192 | XSS sanitization tests | High | sanitizeSearchQuery tests | security.test.ts | PASS |
| 193 | Input boundary tests | Medium | Length, format tests | utils.test.ts | PASS |
| 194 | Security regression tests | High | CI runs tests on every push | CI | TODO |
| 195 | DAST (future) | High | OWASP ZAP or similar | CI | TODO |
| 196 | Penetration test (future) | High | Authorized pen test | External | TODO |

## 42. Ethical & Compliance

| # | Control | Risk | Mitigation | Location | Status |
|---|---------|------|-----------|----------|--------|
| 197 | Ethics documentation | High | ETHICS.md comprehensive | ETHICS.md | PASS |
| 198 | Public-data-only architecture | Critical | No private data access paths | Architecture | PASS |
| 199 | Confidence ≠ certainty documented | High | UI labels + methodology notes | All pages | PASS |
| 200 | Limitations section in reports | High | Required field in ReportsPage | ReportsPage | PASS |
| 201 | Demo data clearly labeled | High | [DEMO] labels in mock data | data/mock.ts | PASS |
| 202 | No illegal OSINT techniques | Critical | No credential/bypass features | Architecture | PASS |
| 203 | Source attribution enforced | High | Source required for evidence | EvidencePage | PASS |
| 204 | GDPR data minimization | High | Minimal fields, delete flows | All pages | PASS |

---

## Summary

| Status | Count |
|--------|-------|
| PASS | 71 |
| TODO | 99 |
| N/A | 14 |
| FAIL | 0 |

Most TODO items require a backend implementation. All frontend security controls applicable to the current demo build are PASS. No items are FAIL.

---

*Last updated: 2024-12. This document should be updated with every significant code or architecture change.*

---

## Known Vulnerability Disclosure

As of the last audit, the following vulnerabilities exist in **development-only** dependencies.
These packages are NOT present in the production build (`dist/`) and do not affect deployed users.

| Package | Severity | Note |
|---------|----------|------|
| vite | High | Dev server only; not in production bundle |
| vitest | Critical | Test runner only; not deployed |
| @vitest/ui | Critical | Test UI only; not deployed |

**Production impact: None.** These only affect developer machines running `npm run dev` or `npm test`.
The `dist/` build output contains none of these packages.

Mitigation: Lock down development environment access; do not expose dev server publicly.
Monitor upstream for fixes and upgrade when available.
