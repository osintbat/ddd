# BrokeBase — Ethics Policy

## Purpose

BrokeBase is designed as a professional OSINT (Open Source Intelligence) workspace
for organizing, correlating, and analyzing information that is **publicly available
and legally accessible**.

This platform is intended for:

- **Security research** conducted with proper authorization
- **Investigative journalism** on matters of public interest
- **Academic research** on publicly available information
- **Due diligence** using public records and disclosures
- **Threat intelligence** from public indicators
- **Fact-checking** and verification of public claims
- **Corporate research** using publicly filed documents

---

## What BrokeBase Is NOT For

BrokeBase must **never** be used to:

- Steal, harvest, or brute-force credentials
- Access systems or accounts without authorization
- Bypass authentication, paywalls, or access controls
- Scrape or enumerate private APIs
- Build profiles for stalking, harassment, or doxxing
- Target individuals for discrimination or harm
- Circumvent robots.txt or access restrictions
- Aggregate data in ways that violate applicable laws (GDPR, CCPA, etc.)
- Conduct surveillance without lawful authority
- Create data sets that constitute illegal processing of personal data

---

## Principles

### 1. Public Data Only

BrokeBase operates exclusively on information that is:
- Genuinely publicly accessible
- Published without access restriction
- Obtainable without bypassing controls

### 2. Source Attribution

Every finding must reference its originating public source. BrokeBase
enforces this through the source and evidence tracking system.

### 3. Confidence Is Not Certainty

Confidence indicators in BrokeBase are methodological assessments only.
They do not constitute proof. Reports must include a Limitations section
acknowledging that public sources may be incomplete, inaccurate, or outdated.

### 4. Data Minimization

Collect only what is necessary for the stated research purpose. Do not
retain data longer than needed. Delete investigations and evidence when
the research purpose is complete.

### 5. Harm Avoidance

Before conducting any investigation, consider whether the research could
cause disproportionate harm to individuals. Public availability does not
equal ethical appropriateness in all contexts.

---

## Legal Compliance

Users of BrokeBase are responsible for ensuring their use complies with:

- Applicable national and local laws
- Computer fraud and access laws (CFAA, Computer Misuse Act, etc.)
- Data protection regulations (GDPR, CCPA, etc.)
- Journalistic and research ethics standards
- Terms of service of any data sources consulted

---

## Reporting Misuse

If you observe BrokeBase being used for harmful, illegal, or unethical purposes,
please report it via the project's issue tracker or security contact.

---

*BrokeBase is a tool. Its ethical quality depends entirely on the intentions
and conduct of those who use it. Use it responsibly.*
