import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Command } from 'cmdk';
import {
  Search,
  FolderOpen,
  Users,
  Globe,
  Clock,
  BarChart3,
  Settings,
  Plus,

  Database,
  GitBranch,
} from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { useAppStore } from '@/lib/store';

const COMMANDS = [
  { id: 'search', label: 'Search intelligence', icon: Search, href: '/app/search', shortcut: '' },
  { id: 'investigations', label: 'View investigations', icon: FolderOpen, href: '/app/investigations', shortcut: '' },
  { id: 'new-inv', label: 'New investigation', icon: Plus, href: '/app/investigations?new=true', shortcut: '' },
  { id: 'entities', label: 'View entities', icon: Users, href: '/app/entities', shortcut: '' },
  { id: 'sources', label: 'View sources', icon: Globe, href: '/app/sources', shortcut: '' },
  { id: 'relationships', label: 'Relationship graph', icon: GitBranch, href: '/app/relationships', shortcut: '' },
  { id: 'timeline', label: 'Timeline', icon: Clock, href: '/app/timeline', shortcut: '' },
  { id: 'evidence', label: 'Evidence', icon: Database, href: '/app/evidence', shortcut: '' },
  { id: 'reports', label: 'Reports', icon: BarChart3, href: '/app/reports', shortcut: '' },
  { id: 'settings', label: 'Settings', icon: Settings, href: '/app/settings', shortcut: '' },
];

export function CommandPalette() {
  const { commandPaletteOpen, setCommandPaletteOpen } = useAppStore();
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  const handleSelect = useCallback(
    (href: string) => {
      setCommandPaletteOpen(false);
      setQuery('');
      navigate(href);
    },
    [navigate, setCommandPaletteOpen]
  );

  useEffect(() => {
    if (!commandPaletteOpen) setQuery('');
  }, [commandPaletteOpen]);

  const filtered = query
    ? COMMANDS.filter((c) => c.label.toLowerCase().includes(query.toLowerCase()))
    : COMMANDS;

  return (
    <Dialog open={commandPaletteOpen} onOpenChange={setCommandPaletteOpen}>
      <DialogContent className="p-0 gap-0 max-w-xl overflow-hidden" showClose={false}>
        <Command className="rounded-2xl" aria-label="Command palette">
          <div className="flex items-center gap-3 px-4 py-3 border-b border-border">
            <Search className="h-4 w-4 text-muted-foreground shrink-0" />
            <Command.Input
              value={query}
              onValueChange={setQuery}
              placeholder="Search commands and intelligence…"
              className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground"
              aria-label="Search commands"
            />
            <kbd className="text-xs text-muted-foreground border border-border rounded px-1.5 py-0.5">ESC</kbd>
          </div>

          <Command.List className="max-h-80 overflow-y-auto p-2" aria-label="Command results">
            <Command.Empty className="py-6 text-center text-sm text-muted-foreground">
              No commands found.
            </Command.Empty>

            <Command.Group heading={<span className="text-xs font-medium text-muted-foreground px-2 py-1 block">Navigation</span>}>
              {filtered.map((cmd) => (
                <Command.Item
                  key={cmd.id}
                  value={cmd.label}
                  onSelect={() => handleSelect(cmd.href)}
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm cursor-pointer aria-selected:bg-muted transition-colors"
                >
                  <cmd.icon className="h-4 w-4 text-muted-foreground shrink-0" />
                  <span>{cmd.label}</span>
                </Command.Item>
              ))}
            </Command.Group>
          </Command.List>

          <div className="border-t border-border px-4 py-2 flex items-center gap-4">
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <kbd className="border border-border rounded px-1 py-0.5">↑↓</kbd> navigate
            </span>
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <kbd className="border border-border rounded px-1 py-0.5">↵</kbd> select
            </span>
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <kbd className="border border-border rounded px-1 py-0.5">ESC</kbd> close
            </span>
          </div>
        </Command>
      </DialogContent>
    </Dialog>
  );
}
