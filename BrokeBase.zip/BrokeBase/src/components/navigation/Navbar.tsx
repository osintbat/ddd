import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const NAV_LINKS = [
  { href: '#platform', label: 'Platform' },
  { href: '#features', label: 'Features' },
  { href: '#intelligence', label: 'Intelligence' },
  { href: '#security', label: 'Security' },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => setMobileOpen(false), [location]);

  const isLanding = location.pathname === '/';

  if (!isLanding) return null;

  return (
    <>
      <nav
        role="navigation"
        aria-label="Main navigation"
        className={cn(
          'fixed top-4 left-1/2 z-50 -translate-x-1/2 w-[calc(100%-2rem)] max-w-5xl',
          'transition-all duration-300 ease-out'
        )}
      >
        <div
          className={cn(
            'flex items-center justify-between rounded-2xl border border-border/50 px-5 py-3',
            'bg-background/80 backdrop-blur-xl shadow-sm',
            scrolled && 'shadow-md border-border/80 bg-background/90'
          )}
        >
          {/* Logo */}
          <Link
            to="/"
            className="flex items-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-lg"
            aria-label="BrokeBase — home"
          >
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-foreground">
              <span className="text-background text-xs font-bold tracking-tight select-none">BB</span>
            </div>
            <span className="text-sm font-semibold tracking-tight">BrokeBase</span>
          </Link>

          {/* Desktop nav links */}
          <ul className="hidden md:flex items-center gap-1" role="list">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="rounded-lg px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>

          {/* CTA */}
          <div className="hidden md:flex items-center gap-2">
            <Link to="/app">
              <Button size="sm" className="rounded-xl">
                Launch Platform
              </Button>
            </Link>
          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden rounded-lg p-1.5 text-muted-foreground hover:text-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="mt-2 rounded-2xl border border-border/80 bg-background/95 backdrop-blur-xl shadow-lg overflow-hidden">
            <ul className="flex flex-col p-2" role="list">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className="flex items-center rounded-xl px-4 py-3 text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
              <li className="mt-2 pt-2 border-t border-border">
                <Link to="/app" className="block">
                  <Button className="w-full rounded-xl" size="sm">
                    Launch Platform
                  </Button>
                </Link>
              </li>
            </ul>
          </div>
        )}
      </nav>

      {/* Spacer to prevent content jumping */}
      <div className="h-20" aria-hidden="true" />
    </>
  );
}
