import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Search,
  FolderOpen,
  Users,
  Globe,
  GitBranch,
  Clock,

  BarChart3,
  Settings,
  ChevronLeft,
  ChevronRight,
  Database,
} from 'lucide-react';
import { useAppStore } from '@/lib/store';
import { cn } from '@/lib/utils';
import { Tooltip } from '@/components/ui/tooltip';

const NAV_ITEMS = [
  { href: '/app', label: 'Overview', icon: LayoutDashboard, exact: true },
  { href: '/app/search', label: 'Search', icon: Search },
  { href: '/app/investigations', label: 'Investigations', icon: FolderOpen },
  { href: '/app/entities', label: 'Entities', icon: Users },
  { href: '/app/sources', label: 'Sources', icon: Globe },
  { href: '/app/relationships', label: 'Relationships', icon: GitBranch },
  { href: '/app/timeline', label: 'Timeline', icon: Clock },
  { href: '/app/evidence', label: 'Evidence', icon: Database },
  { href: '/app/reports', label: 'Reports', icon: BarChart3 },
];

const BOTTOM_ITEMS = [
  { href: '/app/settings', label: 'Settings', icon: Settings },
];

interface SidebarItemProps {
  href: string;
  label: string;
  icon: React.ElementType;
  exact?: boolean;
  collapsed: boolean;
}

function SidebarItem({ href, label, icon: Icon, exact, collapsed }: SidebarItemProps) {
  const location = useLocation();
  const isActive = exact
    ? location.pathname === href
    : location.pathname.startsWith(href);

  const content = (
    <Link
      to={href}
      aria-label={label}
      aria-current={isActive ? 'page' : undefined}
      className={cn(
        'flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring min-h-[44px]',
        collapsed ? 'justify-center px-2' : '',
        isActive
          ? 'bg-foreground text-background'
          : 'text-muted-foreground hover:text-foreground hover:bg-muted'
      )}
    >
      <Icon className="h-4 w-4 shrink-0" />
      {!collapsed && <span className="truncate">{label}</span>}
    </Link>
  );

  if (collapsed) {
    return <Tooltip content={label} side="right">{content}</Tooltip>;
  }

  return content;
}

export function Sidebar() {
  const { sidebarOpen, setSidebarOpen, isDemoMode } = useAppStore();

  return (
    <aside
      className={cn(
        'hidden md:flex flex-col border-r border-border bg-background transition-all duration-200 ease-in-out shrink-0',
        sidebarOpen ? 'w-56' : 'w-16'
      )}
      aria-label="Application sidebar"
    >
      {/* Logo area */}
      <div className={cn('flex items-center border-b border-border h-14 px-3', sidebarOpen ? 'gap-3' : 'justify-center')}>
        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-foreground">
          <span className="text-background text-xs font-bold select-none">BB</span>
        </div>
        {sidebarOpen && (
          <span className="font-semibold text-sm tracking-tight truncate">BrokeBase</span>
        )}
      </div>

      {/* Demo mode banner */}
      {isDemoMode && sidebarOpen && (
        <div className="mx-3 mt-3 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 px-3 py-2">
          <p className="text-xs text-amber-700 dark:text-amber-400 font-medium">Demo Mode</p>
          <p className="text-xs text-amber-600/80 dark:text-amber-500/80 mt-0.5">Showing synthetic data</p>
        </div>
      )}

      {/* Nav items */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5" aria-label="Primary navigation">
        {NAV_ITEMS.map((item) => (
          <SidebarItem
            key={item.href}
            {...item}
            collapsed={!sidebarOpen}
          />
        ))}
      </nav>

      {/* Bottom items */}
      <div className="border-t border-border py-3 px-2 space-y-0.5">
        {BOTTOM_ITEMS.map((item) => (
          <SidebarItem
            key={item.href}
            {...item}
            collapsed={!sidebarOpen}
          />
        ))}

        {/* Collapse toggle */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          aria-label={sidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
          className={cn(
            'flex items-center gap-3 w-full rounded-lg px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-colors min-h-[44px]',
            !sidebarOpen && 'justify-center px-2'
          )}
        >
          {sidebarOpen ? (
            <>
              <ChevronLeft className="h-4 w-4 shrink-0" />
              <span>Collapse</span>
            </>
          ) : (
            <Tooltip content="Expand sidebar" side="right">
              <ChevronRight className="h-4 w-4 shrink-0" />
            </Tooltip>
          )}
        </button>
      </div>
    </aside>
  );
}
