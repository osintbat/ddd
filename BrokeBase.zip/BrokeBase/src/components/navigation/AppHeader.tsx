import { useEffect } from 'react';
import { Search, Sun, Moon, Keyboard, Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tooltip } from '@/components/ui/tooltip';
import { useAppStore } from '@/lib/store';

interface AppHeaderProps {
  title?: string;
  description?: string;
}

export function AppHeader({ title, description }: AppHeaderProps) {
  const { theme, toggleTheme, setCommandPaletteOpen, setSidebarOpen, sidebarOpen } = useAppStore();

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(true);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [setCommandPaletteOpen]);

  return (
    <header className="flex h-14 items-center gap-3 border-b border-border bg-background px-4 shrink-0">
      {/* Mobile sidebar toggle */}
      <button
        className="md:hidden rounded-lg p-1.5 text-muted-foreground hover:text-foreground transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring min-h-[44px] min-w-[44px] flex items-center justify-center"
        onClick={() => setSidebarOpen(!sidebarOpen)}
        aria-label="Toggle navigation"
      >
        <Menu className="h-5 w-5" />
      </button>

      {/* Page title */}
      <div className="flex-1 min-w-0">
        {title && (
          <div>
            <h1 className="text-sm font-semibold truncate">{title}</h1>
            {description && (
              <p className="text-xs text-muted-foreground truncate hidden sm:block">{description}</p>
            )}
          </div>
        )}
      </div>

      <div className="flex items-center gap-1">
        {/* Search / Command palette trigger */}
        <Tooltip content="Search (⌘K)">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCommandPaletteOpen(true)}
            className="hidden sm:flex gap-2 text-muted-foreground w-44 justify-start"
            aria-label="Open search"
          >
            <Search className="h-3.5 w-3.5" />
            <span className="text-xs">Search intelligence…</span>
            <kbd className="ml-auto text-xs bg-muted rounded px-1">⌘K</kbd>
          </Button>
        </Tooltip>

        <Tooltip content="Search (⌘K)">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setCommandPaletteOpen(true)}
            className="sm:hidden"
            aria-label="Search"
          >
            <Search className="h-4 w-4" />
          </Button>
        </Tooltip>

        {/* Keyboard shortcuts */}
        <Tooltip content="Keyboard shortcuts">
          <Button variant="ghost" size="icon" aria-label="View keyboard shortcuts">
            <Keyboard className="h-4 w-4" />
          </Button>
        </Tooltip>

        {/* Theme toggle */}
        <Tooltip content={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}>
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleTheme}
            aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
          >
            {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          </Button>
        </Tooltip>
      </div>
    </header>
  );
}
