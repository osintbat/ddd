import { Component, type ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  errorId: string;
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, errorId: '' };

  static getDerivedStateFromError(): Partial<State> {
    return { hasError: true, errorId: Math.random().toString(36).slice(2, 8).toUpperCase() };
  }

  componentDidCatch(error: Error) {
    // Log error without exposing stack to UI
    console.error('[BrokeBase ErrorBoundary]', error.message);
  }

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) return this.props.fallback;
      return (
        <div className="flex flex-col items-center justify-center min-h-[60vh] p-8 text-center" role="alert" aria-live="assertive">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-muted mb-4">
            <AlertTriangle className="h-6 w-6 text-muted-foreground" />
          </div>
          <h2 className="text-lg font-semibold mb-2">Something went wrong</h2>
          <p className="text-sm text-muted-foreground max-w-sm mb-1">
            An unexpected error occurred. The team has been notified.
          </p>
          <p className="text-xs text-muted-foreground mb-6">
            Error reference: <code className="font-mono">{this.state.errorId}</code>
          </p>
          <div className="flex gap-3">
            <Button
              onClick={() => this.setState({ hasError: false, errorId: '' })}
              className="gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Try again
            </Button>
            <Button variant="outline" onClick={() => (window.location.href = '/app')}>
              Return to dashboard
            </Button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
