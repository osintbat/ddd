import {
  User,
  Building2,
  Globe,
  Server,
  Mail,
  AtSign,
  Link,
  MapPin,
} from 'lucide-react';
import type { EntityType } from '@/types';

import { cn } from '@/lib/utils';

const TYPE_CONFIG: Record<EntityType, { label: string; icon: React.ElementType; color: string }> = {
  person: { label: 'Person', icon: User, color: 'text-blue-600 dark:text-blue-400' },
  organization: { label: 'Organization', icon: Building2, color: 'text-purple-600 dark:text-purple-400' },
  domain: { label: 'Domain', icon: Globe, color: 'text-green-600 dark:text-green-400' },
  ip: { label: 'IP Address', icon: Server, color: 'text-orange-600 dark:text-orange-400' },
  email: { label: 'Email', icon: Mail, color: 'text-red-600 dark:text-red-400' },
  username: { label: 'Username', icon: AtSign, color: 'text-cyan-600 dark:text-cyan-400' },
  url: { label: 'URL', icon: Link, color: 'text-indigo-600 dark:text-indigo-400' },
  location: { label: 'Location', icon: MapPin, color: 'text-emerald-600 dark:text-emerald-400' },
};

interface EntityTypeIconProps {
  type: EntityType;
  className?: string;
}

export function EntityTypeIcon({ type, className }: EntityTypeIconProps) {
  const { icon: Icon, color } = TYPE_CONFIG[type];
  return <Icon className={cn('h-4 w-4', color, className)} />;
}

interface EntityTypeBadgeProps {
  type: EntityType;
  className?: string;
}

export function EntityTypeBadge({ type, className }: EntityTypeBadgeProps) {
  const { label, icon: Icon, color } = TYPE_CONFIG[type];
  return (
    <span className={cn('inline-flex items-center gap-1.5', className)}>
      <Icon className={cn('h-3.5 w-3.5', color)} />
      <span className="text-xs text-muted-foreground">{label}</span>
    </span>
  );
}
