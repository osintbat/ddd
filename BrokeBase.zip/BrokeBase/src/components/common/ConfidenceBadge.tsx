import { Badge } from '@/components/ui/badge';
import type { ConfidenceLevel } from '@/types';

interface ConfidenceBadgeProps {
  level: ConfidenceLevel;
  className?: string;
}

const CONFIG: Record<ConfidenceLevel, { label: string; variant: 'default' | 'success' | 'warning' | 'destructive' | 'secondary' | 'outline' }> = {
  low: { label: 'Low', variant: 'outline' },
  medium: { label: 'Medium', variant: 'warning' },
  high: { label: 'High', variant: 'default' },
  verified: { label: 'Verified', variant: 'success' },
};

export function ConfidenceBadge({ level, className }: ConfidenceBadgeProps) {
  const { label, variant } = CONFIG[level];
  return (
    <Badge variant={variant} className={className}>
      {label}
    </Badge>
  );
}
