import { cn } from '@/lib/utils';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'secondary' | 'outline' | 'destructive' | 'success' | 'warning';
  className?: string;
}

export function Badge({ children, variant = 'default', className }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ring-1 ring-inset',
        {
          'bg-foreground/5 text-foreground ring-foreground/10': variant === 'default',
          'bg-muted text-muted-foreground ring-border': variant === 'secondary',
          'bg-transparent text-foreground ring-border': variant === 'outline',
          'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-400/10 dark:text-red-400 dark:ring-red-400/20':
            variant === 'destructive',
          'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-400/10 dark:text-emerald-400 dark:ring-emerald-400/20':
            variant === 'success',
          'bg-amber-50 text-amber-700 ring-amber-600/20 dark:bg-amber-400/10 dark:text-amber-400 dark:ring-amber-400/20':
            variant === 'warning',
        },
        className
      )}
    >
      {children}
    </span>
  );
}
