import { create } from 'zustand';
import type {
  Investigation,
  Entity,
  Source,
  Evidence,
  TimelineEvent,
  EntityRelationship,
} from '@/types';
import {
  DEMO_INVESTIGATIONS,
  DEMO_ENTITIES,
  DEMO_SOURCES,
  DEMO_EVIDENCE,
  DEMO_TIMELINE,
  DEMO_RELATIONSHIPS,
} from '@/data/mock';

interface AppState {
  isDemoMode: boolean;
  theme: 'light' | 'dark';
  investigations: Investigation[];
  entities: Entity[];
  sources: Source[];
  evidence: Evidence[];
  timeline: TimelineEvent[];
  relationships: EntityRelationship[];
  commandPaletteOpen: boolean;
  sidebarOpen: boolean;
  activeInvestigationId: string | null;

  setTheme: (theme: 'light' | 'dark') => void;
  toggleTheme: () => void;
  setCommandPaletteOpen: (open: boolean) => void;
  setSidebarOpen: (open: boolean) => void;
  setActiveInvestigation: (id: string | null) => void;

  addInvestigation: (investigation: Investigation) => void;
  updateInvestigation: (id: string, data: Partial<Investigation>) => void;
  deleteInvestigation: (id: string) => void;

  addEntity: (entity: Entity) => void;
  updateEntity: (id: string, data: Partial<Entity>) => void;
  deleteEntity: (id: string) => void;

  addSource: (source: Source) => void;
  deleteSource: (id: string) => void;

  addEvidence: (evidence: Evidence) => void;
  deleteEvidence: (id: string) => void;

  addTimelineEvent: (event: TimelineEvent) => void;
  deleteTimelineEvent: (id: string) => void;
}

export const useAppStore = create<AppState>((set) => ({
  isDemoMode: true,
  theme: 'light',
  investigations: DEMO_INVESTIGATIONS,
  entities: DEMO_ENTITIES,
  sources: DEMO_SOURCES,
  evidence: DEMO_EVIDENCE,
  timeline: DEMO_TIMELINE,
  relationships: DEMO_RELATIONSHIPS,
  commandPaletteOpen: false,
  sidebarOpen: true,
  activeInvestigationId: null,

  setTheme: (theme) => {
    set({ theme });
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  },

  toggleTheme: () =>
    set((state) => {
      const newTheme = state.theme === 'light' ? 'dark' : 'light';
      if (newTheme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      return { theme: newTheme };
    }),

  setCommandPaletteOpen: (open) => set({ commandPaletteOpen: open }),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setActiveInvestigation: (id) => set({ activeInvestigationId: id }),

  addInvestigation: (investigation) =>
    set((state) => ({ investigations: [...state.investigations, investigation] })),
  updateInvestigation: (id, data) =>
    set((state) => ({
      investigations: state.investigations.map((inv) =>
        inv.id === id ? { ...inv, ...data, updatedAt: new Date().toISOString() } : inv
      ),
    })),
  deleteInvestigation: (id) =>
    set((state) => ({
      investigations: state.investigations.filter((inv) => inv.id !== id),
    })),

  addEntity: (entity) =>
    set((state) => ({ entities: [...state.entities, entity] })),
  updateEntity: (id, data) =>
    set((state) => ({
      entities: state.entities.map((e) =>
        e.id === id ? { ...e, ...data, updatedAt: new Date().toISOString() } : e
      ),
    })),
  deleteEntity: (id) =>
    set((state) => ({ entities: state.entities.filter((e) => e.id !== id) })),

  addSource: (source) =>
    set((state) => ({ sources: [...state.sources, source] })),
  deleteSource: (id) =>
    set((state) => ({ sources: state.sources.filter((s) => s.id !== id) })),

  addEvidence: (ev) =>
    set((state) => ({ evidence: [...state.evidence, ev] })),
  deleteEvidence: (id) =>
    set((state) => ({ evidence: state.evidence.filter((e) => e.id !== id) })),

  addTimelineEvent: (event) =>
    set((state) => ({ timeline: [...state.timeline, event] })),
  deleteTimelineEvent: (id) =>
    set((state) => ({ timeline: state.timeline.filter((t) => t.id !== id) })),
}));
