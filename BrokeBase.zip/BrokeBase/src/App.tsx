import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ErrorBoundary } from '@/components/common/ErrorBoundary';
import { Navbar } from '@/components/navigation/Navbar';
import { AppLayout } from '@/components/layout/AppLayout';
import { Toaster } from '@/components/ui/toaster';

import { LandingPage } from '@/pages/LandingPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { SearchPage } from '@/pages/SearchPage';
import { InvestigationsPage } from '@/pages/InvestigationsPage';
import { InvestigationDetailPage } from '@/pages/InvestigationDetailPage';
import { EntitiesPage } from '@/pages/EntitiesPage';
import { EntityDetailPage } from '@/pages/EntityDetailPage';
import { SourcesPage } from '@/pages/SourcesPage';
import { EvidencePage } from '@/pages/EvidencePage';
import { TimelinePage } from '@/pages/TimelinePage';
import { RelationshipsPage } from '@/pages/RelationshipsPage';
import { ReportsPage } from '@/pages/ReportsPage';
import { SettingsPage } from '@/pages/SettingsPage';
import { NotFoundPage } from '@/pages/NotFoundPage';

function LandingLayout() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <ErrorBoundary>
        <LandingPage />
      </ErrorBoundary>
      <Toaster />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingLayout />} />
        <Route path="/app" element={<ErrorBoundary><AppLayout /></ErrorBoundary>}>
          <Route index element={<DashboardPage />} />
          <Route path="search" element={<SearchPage />} />
          <Route path="investigations" element={<InvestigationsPage />} />
          <Route path="investigations/:id" element={<InvestigationDetailPage />} />
          <Route path="entities" element={<EntitiesPage />} />
          <Route path="entities/:id" element={<EntityDetailPage />} />
          <Route path="sources" element={<SourcesPage />} />
          <Route path="evidence" element={<EvidencePage />} />
          <Route path="timeline" element={<TimelinePage />} />
          <Route path="relationships" element={<RelationshipsPage />} />
          <Route path="reports" element={<ReportsPage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </BrowserRouter>
  );
}
