export type EntityType =
  | 'person'
  | 'organization'
  | 'domain'
  | 'ip'
  | 'email'
  | 'username'
  | 'url'
  | 'location';

export type ConfidenceLevel = 'low' | 'medium' | 'high' | 'verified';

export type InvestigationStatus = 'draft' | 'active' | 'archived';

export type Priority = 'low' | 'medium' | 'high' | 'critical';

export type SourceType =
  | 'web'
  | 'social'
  | 'news'
  | 'government'
  | 'academic'
  | 'corporate'
  | 'leaks'
  | 'other';

export type RelationshipType =
  | 'associated_with'
  | 'references'
  | 'linked_to'
  | 'owned_by'
  | 'mentioned_by'
  | 'member_of'
  | 'located_at';

export interface Entity {
  id: string;
  type: EntityType;
  name: string;
  description?: string;
  confidence: ConfidenceLevel;
  sources: string[];
  tags: string[];
  metadata: Record<string, unknown>;
  createdAt: string;
  updatedAt: string;
  investigationId?: string;
}

export interface Source {
  id: string;
  url: string;
  domain: string;
  title: string;
  publicationDate?: string;
  accessedDate: string;
  sourceType: SourceType;
  confidence: ConfidenceLevel;
  notes?: string;
  investigationId?: string;
  createdAt: string;
}

export interface Evidence {
  id: string;
  sourceId: string;
  url: string;
  timestamp: string;
  snippet?: string;
  notes?: string;
  confidence: ConfidenceLevel;
  hash?: string;
  entityIds: string[];
  investigationId?: string;
  createdAt: string;
}

export interface Investigation {
  id: string;
  title: string;
  description?: string;
  tags: string[];
  status: InvestigationStatus;
  priority: Priority;
  entityCount: number;
  sourceCount: number;
  evidenceCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface TimelineEvent {
  id: string;
  date: string;
  title: string;
  description?: string;
  sourceId?: string;
  entityIds: string[];
  confidence: ConfidenceLevel;
  investigationId?: string;
  createdAt: string;
}

export interface EntityRelationship {
  id: string;
  sourceEntityId: string;
  targetEntityId: string;
  type: RelationshipType;
  confidence: ConfidenceLevel;
  notes?: string;
  sourceIds: string[];
  createdAt: string;
}

export interface Report {
  id: string;
  title: string;
  executiveSummary?: string;
  investigationId: string;
  status: 'draft' | 'published';
  methodology?: string;
  limitations?: string;
  createdAt: string;
  updatedAt: string;
}

export interface SearchResult {
  type: 'entity' | 'source' | 'evidence' | 'investigation';
  id: string;
  title: string;
  description?: string;
  confidence?: ConfidenceLevel;
  investigationId?: string;
}

export interface DashboardStats {
  activeInvestigations: number;
  totalEntities: number;
  totalSources: number;
  totalEvidence: number;
  recentActivity: number;
}
