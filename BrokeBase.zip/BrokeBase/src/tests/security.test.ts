import { describe, it, expect } from 'vitest';
import { isValidUrl, isPrivateIp, sanitizeSearchQuery, extractDomain } from '@/lib/utils';

// Security-focused tests

describe('URL Security — SSRF Prevention', () => {
  const BLOCKED_LOCALHOST = [
    'http://localhost/admin',
    'http://localhost:8080',
    'http://127.0.0.1',
    'http://127.0.0.1:3000/secret',
  ];
  const BLOCKED_PRIVATE = [
    'http://10.0.0.1',
    'http://192.168.1.1',
    'http://172.16.0.1',
  ];
  const BLOCKED_PROTOCOLS = [
    'javascript:alert(1)',
    'data:text/html,xss',
    'file:///etc/passwd',
    'ftp://files.internal',
  ];

  BLOCKED_LOCALHOST.forEach((url) => {
    it(`blocks localhost URL: ${url}`, () => {
      const hostname = (() => { try { return new URL(url).hostname; } catch { return ''; } })();
      const isLoopback = /^(localhost|127\.|0\.0\.0\.0)/i.test(hostname);
      expect(isLoopback || !isValidUrl(url)).toBe(true);
    });
  });

  BLOCKED_PRIVATE.forEach((url) => {
    it(`blocks private IP URL: ${url}`, () => {
      const hostname = (() => { try { return new URL(url).hostname; } catch { return ''; } })();
      expect(isPrivateIp(hostname) || !isValidUrl(url)).toBe(true);
    });
  });

  BLOCKED_PROTOCOLS.forEach((url) => {
    it(`blocks dangerous protocol: ${url}`, () => {
      expect(isValidUrl(url)).toBe(false);
    });
  });

  it('allows legitimate public HTTPS URLs', () => {
    const SAFE = [
      'https://www.sec.gov',
      'https://opencorporates.com',
      'https://crt.sh',
      'https://bgpview.io',
    ];
    SAFE.forEach((url) => expect(isValidUrl(url)).toBe(true));
  });
});

describe('Input Validation — XSS Prevention', () => {
  const XSS_VECTORS = [
    '<script>alert(1)</script>',
    '"><img src=x onerror=alert(1)>',
    "'; DROP TABLE entities; --",
    '<svg onload=alert(document.cookie)>',
  ];

  XSS_VECTORS.forEach((vector) => {
    it(`sanitizes XSS vector: ${vector.slice(0, 30)}`, () => {
      const sanitized = sanitizeSearchQuery(vector);
      expect(sanitized).not.toContain('<');
      expect(sanitized).not.toContain('>');
    });
  });
});

describe('Path Traversal Prevention', () => {
  const TRAVERSAL_ATTEMPTS = [
    '../../../etc/passwd',
    '..\\..\\windows\\system32',
    '%2e%2e%2f%2e%2e%2f',
    '....//....//etc/passwd',
  ];

  TRAVERSAL_ATTEMPTS.forEach((attempt) => {
    it(`sanitizes path traversal: ${attempt}`, () => {
      // These should not be valid URLs
      expect(isValidUrl(attempt)).toBe(false);
    });
  });
});

describe('Domain Extraction Security', () => {
  it('extracts domain safely from valid URLs', () => {
    expect(extractDomain('https://example.com/path?q=1')).toBe('example.com');
  });
  it('handles malformed URLs gracefully', () => {
    const result = extractDomain('not-a-url');
    expect(typeof result).toBe('string');
    expect(result.length).toBeGreaterThan(0);
  });
});
