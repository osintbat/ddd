import { describe, it, expect } from 'vitest';
import {
  cn,
  formatDate,
  truncate,
  generateId,
  extractDomain,
  isValidUrl,
  isPrivateIp,
  sanitizeSearchQuery,
} from '@/lib/utils';

describe('cn utility', () => {
  it('merges class names', () => {
    expect(cn('a', 'b')).toBe('a b');
    expect(cn('px-4', 'px-2')).toBe('px-2'); // tailwind-merge deduplication
  });
});

describe('formatDate', () => {
  it('formats ISO date strings', () => {
    const result = formatDate('2024-01-15T10:00:00Z');
    expect(result).toContain('2024');
    expect(result).toContain('Jan');
  });
});

describe('truncate', () => {
  it('truncates long strings', () => {
    expect(truncate('hello world', 5)).toBe('hello…');
    expect(truncate('short', 10)).toBe('short');
  });
  it('does not truncate at exact length', () => {
    expect(truncate('exact', 5)).toBe('exact');
  });
});

describe('generateId', () => {
  it('generates unique IDs', () => {
    const ids = new Set(Array.from({ length: 100 }, () => generateId()));
    expect(ids.size).toBe(100);
  });
  it('generates non-empty strings', () => {
    expect(generateId().length).toBeGreaterThan(4);
  });
});

describe('extractDomain', () => {
  it('extracts domain from full URL', () => {
    expect(extractDomain('https://www.example.com/path')).toBe('example.com');
    expect(extractDomain('https://sub.domain.org')).toBe('sub.domain.org');
  });
  it('returns raw string for invalid URL', () => {
    expect(extractDomain('not-a-url')).toBe('not-a-url');
  });
});

describe('isValidUrl', () => {
  it('accepts valid https URLs', () => {
    expect(isValidUrl('https://example.com')).toBe(true);
    expect(isValidUrl('https://sec.gov/filings')).toBe(true);
  });
  it('accepts http URLs', () => {
    expect(isValidUrl('http://example.com')).toBe(true);
  });
  it('rejects javascript: protocol', () => {
    expect(isValidUrl('javascript:alert(1)')).toBe(false);
  });
  it('rejects data: URIs', () => {
    expect(isValidUrl('data:text/html,<h1>xss</h1>')).toBe(false);
  });
  it('rejects file: protocol', () => {
    expect(isValidUrl('file:///etc/passwd')).toBe(false);
  });
  it('rejects malformed input', () => {
    expect(isValidUrl('not a url')).toBe(false);
    expect(isValidUrl('')).toBe(false);
  });
});

describe('isPrivateIp', () => {
  it('detects RFC 1918 private ranges', () => {
    expect(isPrivateIp('10.0.0.1')).toBe(true);
    expect(isPrivateIp('192.168.1.1')).toBe(true);
    expect(isPrivateIp('172.16.0.1')).toBe(true);
    expect(isPrivateIp('172.31.255.255')).toBe(true);
  });
  it('detects loopback', () => {
    expect(isPrivateIp('127.0.0.1')).toBe(true);
    expect(isPrivateIp('::1')).toBe(true);
  });
  it('detects link-local', () => {
    expect(isPrivateIp('169.254.1.1')).toBe(true);
  });
  it('allows public IPs', () => {
    expect(isPrivateIp('203.0.113.1')).toBe(false);
    expect(isPrivateIp('8.8.8.8')).toBe(false);
    expect(isPrivateIp('1.1.1.1')).toBe(false);
  });
});

describe('sanitizeSearchQuery', () => {
  it('trims whitespace', () => {
    expect(sanitizeSearchQuery('  hello  ')).toBe('hello');
  });
  it('removes XSS characters', () => {
    expect(sanitizeSearchQuery('<script>alert(1)</script>')).not.toContain('<');
    expect(sanitizeSearchQuery('"quote"')).not.toContain('"');
  });
  it('truncates to 512 chars', () => {
    const long = 'a'.repeat(600);
    expect(sanitizeSearchQuery(long).length).toBeLessThanOrEqual(512);
  });
  it('preserves normal queries', () => {
    expect(sanitizeSearchQuery('john doe 2024')).toBe('john doe 2024');
    expect(sanitizeSearchQuery('domain.com')).toBe('domain.com');
  });
});
