import { useState, useCallback } from 'react';

export type ToastVariant = 'default' | 'success' | 'error' | 'warning';

export interface Toast {
  id: string;
  title: string;
  description?: string;
  variant?: ToastVariant;
}

let globalToastAdd: ((toast: Omit<Toast, 'id'>) => void) | null = null;

export function setGlobalToastHandler(fn: (toast: Omit<Toast, 'id'>) => void) {
  globalToastAdd = fn;
}

export function toast(t: Omit<Toast, 'id'>) {
  if (globalToastAdd) {
    globalToastAdd(t);
  }
}

export function useToastState() {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = useCallback((t: Omit<Toast, 'id'>) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev, { ...t, id }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((toast) => toast.id !== id));
    }, 4000);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  return { toasts, addToast, removeToast };
}
