import { useState } from 'react';
import { BarChart3, Plus, Trash2, Download } from 'lucide-react';
import { AppHeader } from '@/components/navigation/AppHeader';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { EmptyState } from '@/components/common/EmptyState';
import { useAppStore } from '@/lib/store';
import { formatDate, generateId } from '@/lib/utils';
import { toast } from '@/hooks/useToast';
import type { Report } from '@/types';

interface ReportState {
  reports: Report[];
}

function useReports() {
  const [state, setState] = useState<ReportState>({ reports: [] });
  const addReport = (r: Report) => setState((s) => ({ reports: [...s.reports, r] }));
  const deleteReport = (id: string) => setState((s) => ({ reports: s.reports.filter((r) => r.id !== id) }));
  return { ...state, addReport, deleteReport };
}

function NewReportDialog({ open, onClose, onAdd }: { open: boolean; onClose: () => void; onAdd: (r: Report) => void }) {
  const { investigations } = useAppStore();
  const [title, setTitle] = useState('');
  const [summary, setSummary] = useState('');
  const [methodology, setMethodology] = useState('');
  const [limitations, setLimitations] = useState('');
  const [investigationId, setInvestigationId] = useState('');

  const handleSubmit = () => {
    if (!title.trim() || !investigationId) return;
    const report: Report = {
      id: generateId(),
      title: title.trim().slice(0, 300),
      executiveSummary: summary.trim().slice(0, 2000) || undefined,
      investigationId,
      status: 'draft',
      methodology: methodology.trim().slice(0, 2000) || undefined,
      limitations: (limitations.trim() || 'All findings are based on publicly available sources. Confidence indicators are methodological assessments and do not guarantee accuracy. Independent verification is recommended before drawing conclusions.').slice(0, 2000),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    onAdd(report);
    toast({ title: 'Report created', variant: 'success' });
    setTitle(''); setSummary(''); setMethodology(''); setLimitations(''); setInvestigationId('');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>New Report</DialogTitle>
          <DialogDescription>Compile investigation findings into a structured report. Reports must include a Limitations section.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-2 max-h-[60vh] overflow-y-auto">
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="rpt-title">Title <span className="text-destructive">*</span></label>
            <Input id="rpt-title" placeholder="Report title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={300} autoFocus />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Investigation <span className="text-destructive">*</span></label>
            <Select value={investigationId} onValueChange={setInvestigationId}>
              <SelectTrigger><SelectValue placeholder="Select investigation" /></SelectTrigger>
              <SelectContent>
                {investigations.map((i) => <SelectItem key={i.id} value={i.id}>{i.title}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="rpt-summary">Executive Summary</label>
            <textarea id="rpt-summary" placeholder="High-level summary of findings..." value={summary} onChange={(e) => setSummary(e.target.value)} maxLength={2000} rows={4}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring placeholder:text-muted-foreground" />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="rpt-method">Methodology</label>
            <textarea id="rpt-method" placeholder="Describe the research methodology used (sources queried, tools used, process followed)..." value={methodology} onChange={(e) => setMethodology(e.target.value)} maxLength={2000} rows={3}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring placeholder:text-muted-foreground" />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="rpt-limits">
              Limitations & Source Reliability <span className="text-xs text-muted-foreground">(required)</span>
            </label>
            <textarea id="rpt-limits"
              placeholder="All findings are based on publicly available sources. Confidence indicators are methodological assessments and do not guarantee accuracy..."
              value={limitations} onChange={(e) => setLimitations(e.target.value)} maxLength={2000} rows={3}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring placeholder:text-muted-foreground" />
            <p className="text-xs text-muted-foreground">Reports must acknowledge source limitations. A default disclaimer will be used if left empty.</p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!title.trim() || !investigationId}>Create Report</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function ReportsPage() {
  const { investigations } = useAppStore();
  const { reports, addReport, deleteReport } = useReports();
  const [newOpen, setNewOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Report | null>(null);
  const [expandedReport, setExpandedReport] = useState<string | null>(null);

  const getInvestigation = (id: string) => investigations.find((i) => i.id === id);

  return (
    <>
      <AppHeader title="Reports" description="Compiled investigation reports" />
      <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-4">
        <div className="flex justify-end">
          <Button onClick={() => setNewOpen(true)} className="gap-2">
            <Plus className="h-4 w-4" />New Report
          </Button>
        </div>

        {reports.length === 0 ? (
          <EmptyState
            icon={<BarChart3 className="h-6 w-6" />}
            title="No reports yet"
            description="Compile investigation findings into structured reports with methodology and limitations documentation."
            action={<Button onClick={() => setNewOpen(true)} className="gap-2"><Plus className="h-4 w-4" />New Report</Button>}
          />
        ) : (
          <div className="space-y-3">
            {reports.map((report) => {
              const inv = getInvestigation(report.investigationId);
              const isExpanded = expandedReport === report.id;
              return (
                <Card key={report.id} className="hover:border-foreground/20 transition-all">
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <h3 className="text-sm font-semibold">{report.title}</h3>
                          <Badge variant={report.status === 'published' ? 'success' : 'secondary'}>
                            {report.status}
                          </Badge>
                        </div>
                        {inv && <p className="text-xs text-muted-foreground">Investigation: {inv.title}</p>}
                        <p className="text-xs text-muted-foreground">Created {formatDate(report.createdAt)}</p>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <Button variant="ghost" size="icon" aria-label="Export report" onClick={() => toast({ title: 'Export coming soon', variant: 'default' })}>
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" aria-label="Delete report" onClick={() => setDeleteTarget(report)}>
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <Button variant="ghost" size="sm" className="text-xs" onClick={() => setExpandedReport(isExpanded ? null : report.id)}>
                      {isExpanded ? 'Show less' : 'Show report contents'}
                    </Button>
                    {isExpanded && (
                      <div className="mt-3 space-y-4 border-t border-border pt-3">
                        {report.executiveSummary && (
                          <div>
                            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Executive Summary</h4>
                            <p className="text-sm text-muted-foreground">{report.executiveSummary}</p>
                          </div>
                        )}
                        {report.methodology && (
                          <div>
                            <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1">Methodology</h4>
                            <p className="text-sm text-muted-foreground">{report.methodology}</p>
                          </div>
                        )}
                        {report.limitations && (
                          <div className="rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30 p-3">
                            <h4 className="text-xs font-semibold text-amber-700 dark:text-amber-400 uppercase tracking-wider mb-1">Limitations & Source Reliability</h4>
                            <p className="text-xs text-amber-700/80 dark:text-amber-400/80">{report.limitations}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        <NewReportDialog open={newOpen} onClose={() => setNewOpen(false)} onAdd={addReport} />
        {deleteTarget && (
          <Dialog open onOpenChange={() => setDeleteTarget(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Delete Report</DialogTitle>
                <DialogDescription>Delete <strong>{deleteTarget.title}</strong>? This cannot be undone.</DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
                <Button variant="destructive" onClick={() => { deleteReport(deleteTarget.id); toast({ title: 'Report deleted' }); setDeleteTarget(null); }}>Delete</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </>
  );
}
