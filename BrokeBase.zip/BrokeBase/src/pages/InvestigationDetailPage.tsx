import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Users, Globe, Database, Clock } from 'lucide-react';
import { AppHeader } from '@/components/navigation/AppHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ConfidenceBadge } from '@/components/common/ConfidenceBadge';
import { EmptyState } from '@/components/common/EmptyState';
import { EntityTypeBadge } from '@/components/common/EntityTypeBadge';
import { useAppStore } from '@/lib/store';
import { formatDate, formatRelativeTime } from '@/lib/utils';

export function InvestigationDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { investigations, entities, sources, evidence, timeline } = useAppStore();

  const investigation = investigations.find((i) => i.id === id);

  if (!investigation) {
    return (
      <>
        <AppHeader title="Investigation not found" />
        <div className="p-6">
          <EmptyState
            title="Investigation not found"
            description="This investigation may have been deleted or the link is incorrect."
            action={
              <Button onClick={() => navigate('/app/investigations')}>
                Back to investigations
              </Button>
            }
          />
        </div>
      </>
    );
  }

  const invEntities = entities.filter((e) => e.investigationId === id);
  const invSources = sources.filter((s) => s.investigationId === id);
  const invEvidence = evidence.filter((e) => e.investigationId === id);
  const invTimeline = timeline.filter((t) => t.investigationId === id).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const statusColor = {
    draft: 'secondary' as const,
    active: 'success' as const,
    archived: 'outline' as const,
  }[investigation.status];

  const priorityColor = {
    critical: 'destructive' as const,
    high: 'destructive' as const,
    medium: 'warning' as const,
    low: 'secondary' as const,
  }[investigation.priority];

  return (
    <>
      <AppHeader
        title={investigation.title}
        description={`Investigation · ${investigation.status}`}
      />
      <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-4">
        {/* Back + meta */}
        <div className="flex items-start gap-4">
          <Button variant="ghost" size="sm" onClick={() => navigate('/app/investigations')} className="gap-1.5 shrink-0">
            <ArrowLeft className="h-4 w-4" />
            Back
          </Button>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-1">
              <Badge variant={statusColor}>{investigation.status}</Badge>
              <Badge variant={priorityColor}>{investigation.priority} priority</Badge>
              {investigation.tags.map((tag) => (
                <Badge key={tag} variant="outline">{tag}</Badge>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">
              Created {formatDate(investigation.createdAt)} · Updated {formatRelativeTime(investigation.updatedAt)}
            </p>
          </div>
        </div>

        {investigation.description && (
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground">{investigation.description}</p>
            </CardContent>
          </Card>
        )}

        {/* Summary stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: 'Entities', value: invEntities.length, icon: Users, href: '/app/entities' },
            { label: 'Sources', value: invSources.length, icon: Globe, href: '/app/sources' },
            { label: 'Evidence', value: invEvidence.length, icon: Database, href: '/app/evidence' },
            { label: 'Events', value: invTimeline.length, icon: Clock, href: '/app/timeline' },
          ].map((stat) => (
            <Link key={stat.label} to={stat.href} className="block">
              <Card className="hover:border-foreground/20 transition-colors">
                <CardContent className="p-4 flex items-center gap-3">
                  <stat.icon className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="text-xl font-semibold">{stat.value}</div>
                    <div className="text-xs text-muted-foreground">{stat.label}</div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Tabs */}
        <Tabs defaultValue="entities">
          <TabsList className="w-full sm:w-auto">
            <TabsTrigger value="entities">Entities ({invEntities.length})</TabsTrigger>
            <TabsTrigger value="sources">Sources ({invSources.length})</TabsTrigger>
            <TabsTrigger value="timeline">Timeline ({invTimeline.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="entities" className="mt-4">
            {invEntities.length === 0 ? (
              <EmptyState
                title="No entities"
                description="Add entities to track people, organizations, domains, and other identifiers."
                action={
                  <Link to="/app/entities?new=true">
                    <Button variant="outline" size="sm">Add Entity</Button>
                  </Link>
                }
              />
            ) : (
              <div className="space-y-2">
                {invEntities.map((entity) => (
                  <Link
                    key={entity.id}
                    to={`/app/entities/${entity.id}`}
                    className="flex items-center gap-3 rounded-xl border border-border p-3 hover:border-foreground/20 hover:bg-muted/30 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <div className="h-8 w-8 rounded-lg bg-muted flex items-center justify-center shrink-0">
                      <span className="text-xs font-medium uppercase">{entity.type.slice(0, 2)}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{entity.name}</p>
                      <EntityTypeBadge type={entity.type} />
                    </div>
                    <ConfidenceBadge level={entity.confidence} />
                  </Link>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="sources" className="mt-4">
            {invSources.length === 0 ? (
              <EmptyState title="No sources" description="Add public sources to support your investigation." />
            ) : (
              <div className="space-y-2">
                {invSources.map((source) => (
                  <div key={source.id} className="flex items-center gap-3 rounded-xl border border-border p-3">
                    <Globe className="h-4 w-4 text-muted-foreground shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{source.title}</p>
                      <p className="text-xs text-muted-foreground truncate">{source.domain}</p>
                    </div>
                    <ConfidenceBadge level={source.confidence} />
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="timeline" className="mt-4">
            {invTimeline.length === 0 ? (
              <EmptyState title="No events" description="Timeline events will appear here." />
            ) : (
              <ol className="relative pl-6 border-l border-border space-y-6" aria-label="Investigation timeline">
                {invTimeline.map((event) => (
                  <li key={event.id} className="relative">
                    <div className="absolute -left-[21px] h-2.5 w-2.5 rounded-full bg-foreground/30 ring-2 ring-background mt-1" />
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <time className="text-xs text-muted-foreground" dateTime={event.date}>
                          {formatDate(event.date)}
                        </time>
                        <ConfidenceBadge level={event.confidence} />
                      </div>
                      <p className="text-sm font-medium">{event.title}</p>
                      {event.description && (
                        <p className="text-xs text-muted-foreground">{event.description}</p>
                      )}
                    </div>
                  </li>
                ))}
              </ol>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}
