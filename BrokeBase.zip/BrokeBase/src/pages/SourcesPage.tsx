import { useState } from 'react';
import { Plus, Search, Globe, Trash2, ExternalLink } from 'lucide-react';
import { AppHeader } from '@/components/navigation/AppHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { ConfidenceBadge } from '@/components/common/ConfidenceBadge';
import { EmptyState } from '@/components/common/EmptyState';
import { useAppStore } from '@/lib/store';
import { formatDate, generateId, extractDomain, isValidUrl } from '@/lib/utils';
import { toast } from '@/hooks/useToast';
import type { Source, ConfidenceLevel, SourceType } from '@/types';

const SOURCE_TYPE_LABELS: Record<SourceType, string> = {
  web: 'Web',
  social: 'Social',
  news: 'News',
  government: 'Government',
  academic: 'Academic',
  corporate: 'Corporate',
  leaks: 'Public Leaks',
  other: 'Other',
};

function AddSourceDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { addSource, investigations } = useAppStore();
  const [url, setUrl] = useState('');
  const [title, setTitle] = useState('');
  const [sourceType, setSourceType] = useState<SourceType>('web');
  const [confidence, setConfidence] = useState<ConfidenceLevel>('medium');
  const [notes, setNotes] = useState('');
  const [investigationId, setInvestigationId] = useState('');
  const [urlError, setUrlError] = useState('');

  const handleSubmit = () => {
    if (!url.trim() || !title.trim()) return;
    if (!isValidUrl(url)) {
      setUrlError('Please enter a valid https:// URL.');
      return;
    }
    // SSRF protection: block private/localhost URLs
    const hostname = new URL(url).hostname;
    if (/^(localhost|127\.|0\.0\.0\.0|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/i.test(hostname)) {
      setUrlError('Private or local network URLs are not allowed.');
      return;
    }
    const src: Source = {
      id: generateId(),
      url: url.trim(),
      domain: extractDomain(url),
      title: title.trim().slice(0, 300),
      accessedDate: new Date().toISOString(),
      sourceType,
      confidence,
      notes: notes.trim().slice(0, 1000) || undefined,
      investigationId: investigationId || undefined,
      createdAt: new Date().toISOString(),
    };
    addSource(src);
    toast({ title: 'Source added', variant: 'success' });
    setUrl(''); setTitle(''); setNotes(''); setUrlError(''); setInvestigationId('');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Source</DialogTitle>
          <DialogDescription>Add a public source to your intelligence workspace. Only publicly accessible URLs are supported.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="src-url">URL <span className="text-destructive">*</span></label>
            <Input id="src-url" type="url" placeholder="https://example.com/public-record" value={url}
              onChange={(e) => { setUrl(e.target.value); setUrlError(''); }} maxLength={2048} />
            {urlError && <p className="text-xs text-destructive">{urlError}</p>}
            <p className="text-xs text-muted-foreground">Only https:// public URLs. Private/internal URLs are blocked.</p>
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="src-title">Title <span className="text-destructive">*</span></label>
            <Input id="src-title" placeholder="Descriptive title for this source" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={300} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Source Type</label>
              <Select value={sourceType} onValueChange={(v) => setSourceType(v as SourceType)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(SOURCE_TYPE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Confidence</label>
              <Select value={confidence} onValueChange={(v) => setConfidence(v as ConfidenceLevel)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="verified">Verified</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="src-notes">Notes</label>
            <textarea id="src-notes" placeholder="Methodology notes, caveats..." value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={1000} rows={2} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring placeholder:text-muted-foreground" />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Investigation</label>
            <Select value={investigationId} onValueChange={setInvestigationId}>
              <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="">None</SelectItem>
                {investigations.filter(i => i.status !== 'archived').map((i) => <SelectItem key={i.id} value={i.id}>{i.title}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!url.trim() || !title.trim()}>Add Source</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function SourcesPage() {
  const { sources, deleteSource } = useAppStore();
  const [query, setQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [newOpen, setNewOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Source | null>(null);

  const filtered = sources.filter((s) => {
    const matchQuery = !query || s.title.toLowerCase().includes(query.toLowerCase()) || s.domain.toLowerCase().includes(query.toLowerCase());
    const matchType = typeFilter === 'all' || s.sourceType === typeFilter;
    return matchQuery && matchType;
  });

  return (
    <>
      <AppHeader title="Sources" description="Public source catalog" />
      <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <Input icon={<Search className="h-4 w-4" />} placeholder="Search sources…" value={query} onChange={(e) => setQuery(e.target.value)} className="flex-1" />
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-full sm:w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              {Object.entries(SOURCE_TYPE_LABELS).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button onClick={() => setNewOpen(true)} className="gap-2 shrink-0">
            <Plus className="h-4 w-4" />Add Source
          </Button>
        </div>

        {/* Confidence disclaimer */}
        <div className="rounded-lg border border-border bg-muted/20 px-4 py-2.5" role="note">
          <p className="text-xs text-muted-foreground">
            <strong>Note:</strong> Confidence ratings are methodological indicators reflecting source quality and corroboration.
            They are not guarantees of accuracy. Always verify independently.
          </p>
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            icon={<Globe className="h-6 w-6" />}
            title={query || typeFilter !== 'all' ? 'No sources found' : 'No sources yet'}
            description="Add public sources to document where your intelligence comes from."
            action={!query && typeFilter === 'all' ? <Button onClick={() => setNewOpen(true)} className="gap-2"><Plus className="h-4 w-4" />Add Source</Button> : undefined}
          />
        ) : (
          <div className="space-y-2">
            {filtered.map((src) => (
              <Card key={src.id} className="hover:border-foreground/20 transition-all duration-200">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-muted">
                      <Globe className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <p className="text-sm font-medium truncate">{src.title}</p>
                        <Badge variant="secondary">{SOURCE_TYPE_LABELS[src.sourceType]}</Badge>
                        <ConfidenceBadge level={src.confidence} />
                      </div>
                      <p className="text-xs text-muted-foreground mb-1">{src.domain}</p>
                      {src.notes && <p className="text-xs text-muted-foreground italic">{src.notes}</p>}
                      <p className="text-xs text-muted-foreground mt-1">Accessed {formatDate(src.accessedDate)}</p>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <a href={src.url} target="_blank" rel="noopener noreferrer">
                        <Button variant="ghost" size="icon" aria-label="Open source URL">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </a>
                      <Button variant="ghost" size="icon" aria-label="Delete source" onClick={() => setDeleteTarget(src)}>
                        <Trash2 className="h-4 w-4 text-muted-foreground" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <AddSourceDialog open={newOpen} onClose={() => setNewOpen(false)} />
        {deleteTarget && (
          <Dialog open onOpenChange={() => setDeleteTarget(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Delete Source</DialogTitle>
                <DialogDescription>Delete <strong>{deleteTarget.title}</strong>? This cannot be undone.</DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
                <Button variant="destructive" onClick={() => { deleteSource(deleteTarget.id); toast({ title: 'Source deleted' }); setDeleteTarget(null); }}>Delete</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </>
  );
}
