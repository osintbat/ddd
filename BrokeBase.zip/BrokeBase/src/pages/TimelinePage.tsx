import { useState } from 'react';
import { Clock, Search, Plus, Trash2 } from 'lucide-react';
import { AppHeader } from '@/components/navigation/AppHeader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { ConfidenceBadge } from '@/components/common/ConfidenceBadge';
import { EmptyState } from '@/components/common/EmptyState';
import { useAppStore } from '@/lib/store';
import { formatDate, generateId } from '@/lib/utils';
import { toast } from '@/hooks/useToast';
import type { TimelineEvent, ConfidenceLevel } from '@/types';

function AddEventDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { addTimelineEvent, sources, investigations } = useAppStore();
  const [date, setDate] = useState('');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [confidence, setConfidence] = useState<ConfidenceLevel>('medium');
  const [sourceId, setSourceId] = useState('');
  const [investigationId, setInvestigationId] = useState('');

  const handleSubmit = () => {
    if (!date || !title.trim()) return;
    const event: TimelineEvent = {
      id: generateId(),
      date: new Date(date).toISOString(),
      title: title.trim().slice(0, 300),
      description: description.trim().slice(0, 1000) || undefined,
      sourceId: sourceId || undefined,
      entityIds: [],
      confidence,
      investigationId: investigationId || undefined,
      createdAt: new Date().toISOString(),
    };
    addTimelineEvent(event);
    toast({ title: 'Timeline event added', variant: 'success' });
    setDate(''); setTitle(''); setDescription(''); setSourceId(''); setInvestigationId('');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Timeline Event</DialogTitle>
          <DialogDescription>Add a chronological event to the investigation timeline.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="tl-date">Date <span className="text-destructive">*</span></label>
            <Input id="tl-date" type="date" value={date} onChange={(e) => setDate(e.target.value)} max={new Date().toISOString().split('T')[0]} />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="tl-title">Event Title <span className="text-destructive">*</span></label>
            <Input id="tl-title" placeholder="Brief event description" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={300} />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="tl-desc">Description</label>
            <textarea id="tl-desc" placeholder="Additional context..." value={description} onChange={(e) => setDescription(e.target.value)} maxLength={1000} rows={2}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring placeholder:text-muted-foreground" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Confidence</label>
              <Select value={confidence} onValueChange={(v) => setConfidence(v as ConfidenceLevel)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="verified">Verified</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Source</label>
              <Select value={sourceId} onValueChange={setSourceId}>
                <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="">None</SelectItem>
                  {sources.map((s) => <SelectItem key={s.id} value={s.id}>{s.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Investigation</label>
            <Select value={investigationId} onValueChange={setInvestigationId}>
              <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="">None</SelectItem>
                {investigations.filter(i => i.status !== 'archived').map((i) => <SelectItem key={i.id} value={i.id}>{i.title}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!date || !title.trim()}>Add Event</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function TimelinePage() {
  const { timeline, deleteTimelineEvent, sources } = useAppStore();
  const [query, setQuery] = useState('');
  const [confidenceFilter, setConfidenceFilter] = useState('all');
  const [newOpen, setNewOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<TimelineEvent | null>(null);

  const filtered = timeline
    .filter((ev) => {
      const matchQuery = !query || ev.title.toLowerCase().includes(query.toLowerCase()) || ev.description?.toLowerCase().includes(query.toLowerCase());
      const matchConf = confidenceFilter === 'all' || ev.confidence === confidenceFilter;
      return matchQuery && matchConf;
    })
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // Group by year
  const byYear = filtered.reduce<Record<string, TimelineEvent[]>>((acc, ev) => {
    const year = new Date(ev.date).getFullYear().toString();
    if (!acc[year]) acc[year] = [];
    acc[year].push(ev);
    return acc;
  }, {});

  const years = Object.keys(byYear).sort((a, b) => Number(b) - Number(a));

  return (
    <>
      <AppHeader title="Timeline" description="Chronological event analysis" />
      <div className="p-4 sm:p-6 max-w-4xl mx-auto space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <Input icon={<Search className="h-4 w-4" />} placeholder="Search timeline…" value={query} onChange={(e) => setQuery(e.target.value)} className="flex-1" />
          <Select value={confidenceFilter} onValueChange={setConfidenceFilter}>
            <SelectTrigger className="w-full sm:w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All confidence</SelectItem>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="verified">Verified</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={() => setNewOpen(true)} className="gap-2 shrink-0">
            <Plus className="h-4 w-4" />Add Event
          </Button>
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            icon={<Clock className="h-6 w-6" />}
            title={query || confidenceFilter !== 'all' ? 'No events found' : 'No timeline events'}
            description="Add chronological events to build a picture of your investigation over time."
            action={!query && confidenceFilter === 'all' ? <Button onClick={() => setNewOpen(true)} className="gap-2"><Plus className="h-4 w-4" />Add Event</Button> : undefined}
          />
        ) : (
          <div className="space-y-8">
            {years.map((year) => (
              <div key={year}>
                <div className="flex items-center gap-3 mb-4">
                  <h2 className="text-sm font-semibold text-muted-foreground">{year}</h2>
                  <div className="flex-1 h-px bg-border" />
                </div>
                <ol className="relative pl-6 border-l border-border space-y-6" aria-label={`Events from ${year}`}>
                  {byYear[year].map((event) => {
                    const linkedSrc = sources.find((s) => s.id === event.sourceId);
                    return (
                      <li key={event.id} className="relative group">
                        <div className="absolute -left-[21px] h-2.5 w-2.5 rounded-full bg-foreground/25 ring-2 ring-background mt-1.5 group-hover:bg-foreground/50 transition-colors" />
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap mb-1">
                              <time className="text-xs font-medium text-muted-foreground" dateTime={event.date}>
                                {formatDate(event.date)}
                              </time>
                              <ConfidenceBadge level={event.confidence} />
                            </div>
                            <p className="text-sm font-semibold">{event.title}</p>
                            {event.description && (
                              <p className="text-xs text-muted-foreground mt-1">{event.description}</p>
                            )}
                            {linkedSrc && (
                              <p className="text-xs text-muted-foreground mt-1">
                                Source: <span className="font-medium">{linkedSrc.title}</span>
                              </p>
                            )}
                          </div>
                          <Button
                            variant="ghost" size="icon"
                            className="opacity-0 group-hover:opacity-100 transition-opacity shrink-0"
                            aria-label="Delete event"
                            onClick={() => setDeleteTarget(event)}
                          >
                            <Trash2 className="h-3.5 w-3.5 text-muted-foreground" />
                          </Button>
                        </div>
                      </li>
                    );
                  })}
                </ol>
              </div>
            ))}
          </div>
        )}

        <AddEventDialog open={newOpen} onClose={() => setNewOpen(false)} />
        {deleteTarget && (
          <Dialog open onOpenChange={() => setDeleteTarget(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Delete Event</DialogTitle>
                <DialogDescription>Delete <strong>{deleteTarget.title}</strong>? This cannot be undone.</DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
                <Button variant="destructive" onClick={() => { deleteTimelineEvent(deleteTarget.id); toast({ title: 'Event deleted' }); setDeleteTarget(null); }}>Delete</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </>
  );
}
