import { useRef, useEffect, useState } from 'react';
import { GitBranch, ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';
import { AppHeader } from '@/components/navigation/AppHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

import { ConfidenceBadge } from '@/components/common/ConfidenceBadge';
import { EntityTypeIcon } from '@/components/common/EntityTypeBadge';
import { EmptyState } from '@/components/common/EmptyState';
import { useAppStore } from '@/lib/store';
import type { Entity, EntityRelationship } from '@/types';

// Simple force-directed layout (no external lib)
interface NodePos { id: string; x: number; y: number; }

function computeLayout(entities: Entity[], relationships: EntityRelationship[], width: number, height: number): NodePos[] {
  const N = entities.length;
  if (N === 0) return [];
  const positions: NodePos[] = entities.map((e, i) => ({
    id: e.id,
    x: width / 2 + Math.cos((2 * Math.PI * i) / N) * Math.min(width, height) * 0.35,
    y: height / 2 + Math.sin((2 * Math.PI * i) / N) * Math.min(width, height) * 0.35,
  }));

  // Run simple force iterations
  const ITERATIONS = 80;
  const REPULSION = 3000;
  const SPRING = 0.05;
  const SPRING_LEN = 120;

  for (let iter = 0; iter < ITERATIONS; iter++) {
    const forces = positions.map(() => ({ fx: 0, fy: 0 }));

    // Repulsion
    for (let i = 0; i < positions.length; i++) {
      for (let j = i + 1; j < positions.length; j++) {
        const dx = positions[j].x - positions[i].x;
        const dy = positions[j].y - positions[i].y;
        const dist = Math.max(Math.sqrt(dx * dx + dy * dy), 1);
        const f = REPULSION / (dist * dist);
        forces[i].fx -= (dx / dist) * f;
        forces[i].fy -= (dy / dist) * f;
        forces[j].fx += (dx / dist) * f;
        forces[j].fy += (dy / dist) * f;
      }
    }

    // Spring attraction along edges
    for (const rel of relationships) {
      const si = positions.findIndex((p) => p.id === rel.sourceEntityId);
      const ti = positions.findIndex((p) => p.id === rel.targetEntityId);
      if (si === -1 || ti === -1) continue;
      const dx = positions[ti].x - positions[si].x;
      const dy = positions[ti].y - positions[si].y;
      const dist = Math.max(Math.sqrt(dx * dx + dy * dy), 1);
      const f = SPRING * (dist - SPRING_LEN);
      forces[si].fx += (dx / dist) * f;
      forces[si].fy += (dy / dist) * f;
      forces[ti].fx -= (dx / dist) * f;
      forces[ti].fy -= (dy / dist) * f;
    }

    // Update with damping
    const damping = 1 - iter / ITERATIONS * 0.8;
    for (let i = 0; i < positions.length; i++) {
      positions[i].x += forces[i].fx * damping;
      positions[i].y += forces[i].fy * damping;
      positions[i].x = Math.max(60, Math.min(width - 60, positions[i].x));
      positions[i].y = Math.max(40, Math.min(height - 40, positions[i].y));
    }
  }

  return positions;
}

const ENTITY_COLORS: Record<string, string> = {
  person: '#3b82f6',
  organization: '#8b5cf6',
  domain: '#10b981',
  ip: '#f59e0b',
  email: '#ef4444',
  username: '#06b6d4',
  url: '#6366f1',
  location: '#84cc16',
};

export function RelationshipsPage() {
  const { entities, relationships } = useAppStore();
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(1);
  const [positions, setPositions] = useState<NodePos[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [size, setSize] = useState({ w: 800, h: 480 });

  const selectedEntity = entities.find((e) => e.id === selected);
  const selectedRels = relationships.filter(
    (r) => r.sourceEntityId === selected || r.targetEntityId === selected
  );

  useEffect(() => {
    const obs = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        setSize({ w: Math.max(width, 400), h: Math.max(height, 300) });
      }
    });
    if (containerRef.current) obs.observe(containerRef.current);
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    const pos = computeLayout(entities, relationships, size.w, size.h);
    setPositions(pos);
  }, [entities, relationships, size]);

  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.2, 3));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.2, 0.3));
  const handleReset = () => { setZoom(1); setSelected(null); };

  if (entities.length === 0) {
    return (
      <>
        <AppHeader title="Relationships" description="Entity relationship graph" />
        <div className="p-6">
          <EmptyState
            icon={<GitBranch className="h-6 w-6" />}
            title="No entities to visualize"
            description="Add entities and define relationships to see the graph."
          />
        </div>
      </>
    );
  }

  return (
    <>
      <AppHeader title="Relationships" description="Entity relationship graph" />
      <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-4">
        {/* Demo notice */}
        <div className="rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/40 px-4 py-2.5" role="note">
          <p className="text-xs text-amber-700 dark:text-amber-400">
            All nodes shown represent entirely fictional, synthetic demo entities. Graph is for demonstration only.
          </p>
        </div>

        <div className="grid md:grid-cols-[1fr_280px] gap-4">
          {/* Graph */}
          <Card className="overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border">
              <span className="text-sm font-medium">Entity Graph</span>
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" onClick={handleZoomOut} aria-label="Zoom out"><ZoomOut className="h-4 w-4" /></Button>
                <Button variant="ghost" size="icon" onClick={handleZoomIn} aria-label="Zoom in"><ZoomIn className="h-4 w-4" /></Button>
                <Button variant="ghost" size="icon" onClick={handleReset} aria-label="Reset view"><Maximize2 className="h-4 w-4" /></Button>
              </div>
            </div>
            <div
              ref={containerRef}
              className="w-full"
              style={{ height: '440px', overflow: 'hidden', cursor: 'grab' }}
              role="img"
              aria-label="Entity relationship graph visualization"
            >
              <svg
                ref={svgRef}
                width="100%"
                height="100%"
                viewBox={`0 0 ${size.w} ${size.h}`}
                style={{ transform: `scale(${zoom})`, transformOrigin: 'center', transition: 'transform 0.2s' }}
              >
                <defs>
                  <marker id="arrowhead" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
                    <polygon points="0 0, 8 3, 0 6" fill="hsl(var(--muted-foreground))" opacity="0.4" />
                  </marker>
                </defs>

                {/* Edges */}
                {relationships.map((rel) => {
                  const src = positions.find((p) => p.id === rel.sourceEntityId);
                  const tgt = positions.find((p) => p.id === rel.targetEntityId);
                  if (!src || !tgt) return null;
                  const isHighlighted = selected === rel.sourceEntityId || selected === rel.targetEntityId;
                  return (
                    <g key={rel.id}>
                      <line
                        x1={src.x} y1={src.y} x2={tgt.x} y2={tgt.y}
                        stroke={isHighlighted ? 'hsl(var(--foreground))' : 'hsl(var(--border))'}
                        strokeWidth={isHighlighted ? 1.5 : 1}
                        markerEnd="url(#arrowhead)"
                        strokeDasharray={rel.confidence === 'low' ? '4 3' : undefined}
                        opacity={isHighlighted ? 1 : 0.6}
                      />
                      <text
                        x={(src.x + tgt.x) / 2}
                        y={(src.y + tgt.y) / 2 - 4}
                        fontSize="9"
                        fill="hsl(var(--muted-foreground))"
                        textAnchor="middle"
                        opacity={isHighlighted ? 1 : 0}
                      >
                        {rel.type.replace(/_/g, ' ')}
                      </text>
                    </g>
                  );
                })}

                {/* Nodes */}
                {entities.map((entity) => {
                  const pos = positions.find((p) => p.id === entity.id);
                  if (!pos) return null;
                  const isSelected = selected === entity.id;
                  const isRelated = selectedRels.some(
                    (r) => r.sourceEntityId === entity.id || r.targetEntityId === entity.id
                  );
                  const color = ENTITY_COLORS[entity.type] ?? '#6b7280';
                  const r = isSelected ? 22 : 16;
                  const opacity = selected && !isSelected && !isRelated ? 0.35 : 1;

                  return (
                    <g
                      key={entity.id}
                      transform={`translate(${pos.x}, ${pos.y})`}
                      style={{ cursor: 'pointer', opacity, transition: 'opacity 0.2s' }}
                      onClick={() => setSelected(selected === entity.id ? null : entity.id)}
                      role="button"
                      aria-label={`Entity: ${entity.name}`}
                      tabIndex={0}
                      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') setSelected(selected === entity.id ? null : entity.id); }}
                    >
                      <circle
                        r={r}
                        fill={color}
                        fillOpacity={isSelected ? 1 : 0.15}
                        stroke={color}
                        strokeWidth={isSelected ? 2.5 : 1.5}
                      />
                      <text fontSize="8" fill={isSelected ? 'white' : color} textAnchor="middle" dominantBaseline="central" fontWeight="600">
                        {entity.type.slice(0, 3).toUpperCase()}
                      </text>
                      <text y={r + 12} fontSize="9" fill="hsl(var(--foreground))" textAnchor="middle" fontWeight="500">
                        {entity.name.length > 14 ? entity.name.slice(0, 13) + '…' : entity.name}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>
          </Card>

          {/* Detail panel */}
          <div className="space-y-3">
            {/* Legend */}
            <Card>
              <CardContent className="p-4">
                <h3 className="text-xs font-medium text-muted-foreground mb-3">Entity Types</h3>
                <div className="space-y-1.5">
                  {Object.entries(ENTITY_COLORS).map(([type, color]) => (
                    <div key={type} className="flex items-center gap-2">
                      <div className="h-2.5 w-2.5 rounded-full shrink-0" style={{ backgroundColor: color }} />
                      <span className="text-xs capitalize text-muted-foreground">{type}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Selected entity details */}
            {selectedEntity ? (
              <Card>
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <EntityTypeIcon type={selectedEntity.type} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold truncate">{selectedEntity.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{selectedEntity.type}</p>
                    </div>
                  </div>
                  <ConfidenceBadge level={selectedEntity.confidence} />
                  {selectedRels.length > 0 && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-2">Relationships ({selectedRels.length})</p>
                      <div className="space-y-1.5">
                        {selectedRels.map((rel) => {
                          const otherId = rel.sourceEntityId === selected ? rel.targetEntityId : rel.sourceEntityId;
                          const other = entities.find((e) => e.id === otherId);
                          return (
                            <div key={rel.id} className="flex items-center gap-2 text-xs">
                              <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground shrink-0" />
                              <span className="text-muted-foreground capitalize truncate">
                                {rel.type.replace(/_/g, ' ')} → {other?.name ?? otherId}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="p-4">
                  <p className="text-xs text-muted-foreground text-center py-4">
                    Click a node to view entity details and relationships.
                  </p>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardContent className="p-4">
                <h3 className="text-xs font-medium text-muted-foreground mb-1">Stats</h3>
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between"><span className="text-muted-foreground">Entities</span><span className="font-medium">{entities.length}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Relationships</span><span className="font-medium">{relationships.length}</span></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </>
  );
}
