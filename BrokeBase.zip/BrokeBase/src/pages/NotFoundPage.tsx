import { Link } from 'react-router-dom';
import { Home, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function NotFoundPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-8 text-center" role="main">
      <div className="mb-6">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-foreground mx-auto mb-4">
          <span className="text-background text-xl font-bold">BB</span>
        </div>
        <h1 className="text-6xl font-semibold tracking-tight text-muted-foreground mb-2">404</h1>
        <h2 className="text-xl font-semibold mb-2">Page not found</h2>
        <p className="text-sm text-muted-foreground max-w-sm">
          The page you requested doesn't exist or has been moved.
        </p>
      </div>
      <div className="flex gap-3">
        <Link to="/">
          <Button className="gap-2">
            <Home className="h-4 w-4" />
            Go home
          </Button>
        </Link>
        <Link to="/app">
          <Button variant="outline" className="gap-2">
            <Search className="h-4 w-4" />
            Open platform
          </Button>
        </Link>
      </div>
    </div>
  );
}
