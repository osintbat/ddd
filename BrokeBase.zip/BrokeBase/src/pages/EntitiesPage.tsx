import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Users, Search, Plus, ArrowRight, Trash2 } from 'lucide-react';
import { AppHeader } from '@/components/navigation/AppHeader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { ConfidenceBadge } from '@/components/common/ConfidenceBadge';
import { EntityTypeBadge, EntityTypeIcon } from '@/components/common/EntityTypeBadge';
import { EmptyState } from '@/components/common/EmptyState';
import { useAppStore } from '@/lib/store';
import { formatRelativeTime, generateId } from '@/lib/utils';
import { toast } from '@/hooks/useToast';
import type { Entity, EntityType, ConfidenceLevel } from '@/types';

const ENTITY_TYPES: EntityType[] = ['person', 'organization', 'domain', 'ip', 'email', 'username', 'url', 'location'];

function NewEntityDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { addEntity, investigations } = useAppStore();
  const [name, setName] = useState('');
  const [type, setType] = useState<EntityType>('person');
  const [confidence, setConfidence] = useState<ConfidenceLevel>('medium');
  const [description, setDescription] = useState('');
  const [investigationId, setInvestigationId] = useState('');

  const handleSubmit = () => {
    if (!name.trim()) return;
    const entity: Entity = {
      id: generateId(),
      type,
      name: name.trim().slice(0, 300),
      description: description.trim().slice(0, 1000) || undefined,
      confidence,
      sources: [],
      tags: [],
      metadata: {},
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      investigationId: investigationId || undefined,
    };
    addEntity(entity);
    toast({ title: 'Entity added', variant: 'success' });
    setName(''); setDescription(''); setInvestigationId('');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add Entity</DialogTitle>
          <DialogDescription>Add a new entity to your intelligence workspace.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="ent-name">Name <span className="text-destructive">*</span></label>
            <Input id="ent-name" placeholder="Entity name or identifier" value={name} onChange={(e) => setName(e.target.value)} maxLength={300} autoFocus />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Type</label>
              <Select value={type} onValueChange={(v) => setType(v as EntityType)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {ENTITY_TYPES.map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Confidence</label>
              <Select value={confidence} onValueChange={(v) => setConfidence(v as ConfidenceLevel)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="verified">Verified</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="ent-desc">Description</label>
            <textarea id="ent-desc" placeholder="Optional description..." value={description} onChange={(e) => setDescription(e.target.value)} maxLength={1000} rows={2} className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring placeholder:text-muted-foreground" />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Investigation</label>
            <Select value={investigationId} onValueChange={setInvestigationId}>
              <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="">None</SelectItem>
                {investigations.filter(i => i.status !== 'archived').map((i) => <SelectItem key={i.id} value={i.id}>{i.title}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!name.trim()}>Add Entity</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function EntitiesPage() {
  const { entities, deleteEntity } = useAppStore();
  const [searchParams] = useSearchParams();
  const [query, setQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [newOpen, setNewOpen] = useState(searchParams.get('new') === 'true');
  const [deleteTarget, setDeleteTarget] = useState<Entity | null>(null);

  const filtered = entities.filter((e) => {
    const matchQuery = !query || e.name.toLowerCase().includes(query.toLowerCase()) || e.type.includes(query.toLowerCase());
    const matchType = typeFilter === 'all' || e.type === typeFilter;
    return matchQuery && matchType;
  });

  return (
    <>
      <AppHeader title="Entities" description="People, organizations, domains, and identifiers" />
      <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <Input icon={<Search className="h-4 w-4" />} placeholder="Search entities…" value={query} onChange={(e) => setQuery(e.target.value)} className="flex-1" />
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-full sm:w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              {ENTITY_TYPES.map((t) => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button onClick={() => setNewOpen(true)} className="gap-2 shrink-0">
            <Plus className="h-4 w-4" />Add Entity
          </Button>
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            icon={<Users className="h-6 w-6" />}
            title={query || typeFilter !== 'all' ? 'No entities found' : 'No entities yet'}
            description="Add entities like people, organizations, domains, or IP addresses to your workspace."
            action={!query && typeFilter === 'all' ? <Button onClick={() => setNewOpen(true)} className="gap-2"><Plus className="h-4 w-4" />Add Entity</Button> : undefined}
          />
        ) : (
          <div className="overflow-hidden rounded-xl border border-border">
            <table className="w-full text-sm" role="grid" aria-label="Entities table">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground">Entity</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground hidden sm:table-cell">Type</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground">Confidence</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground hidden md:table-cell">Updated</th>
                  <th className="px-4 py-3 w-20" />
                </tr>
              </thead>
              <tbody>
                {filtered.map((entity) => (
                  <tr key={entity.id} className="border-b border-border/50 last:border-0 hover:bg-muted/30 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <EntityTypeIcon type={entity.type} />
                        <span className="font-medium truncate max-w-[200px]">{entity.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden sm:table-cell">
                      <EntityTypeBadge type={entity.type} />
                    </td>
                    <td className="px-4 py-3">
                      <ConfidenceBadge level={entity.confidence} />
                    </td>
                    <td className="px-4 py-3 text-xs text-muted-foreground hidden md:table-cell">
                      {formatRelativeTime(entity.updatedAt)}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1 justify-end">
                        <Link to={`/app/entities/${entity.id}`}>
                          <Button variant="ghost" size="icon" aria-label={`View ${entity.name}`}>
                            <ArrowRight className="h-4 w-4" />
                          </Button>
                        </Link>
                        <Button variant="ghost" size="icon" aria-label="Delete entity" onClick={() => setDeleteTarget(entity)}>
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <NewEntityDialog open={newOpen} onClose={() => setNewOpen(false)} />

        {deleteTarget && (
          <Dialog open onOpenChange={() => setDeleteTarget(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Delete Entity</DialogTitle>
                <DialogDescription>Delete <strong>{deleteTarget.name}</strong>? This cannot be undone.</DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
                <Button variant="destructive" onClick={() => { deleteEntity(deleteTarget.id); toast({ title: 'Entity deleted' }); setDeleteTarget(null); }}>Delete</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </>
  );
}
