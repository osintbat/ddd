import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  Search,
  GitBranch,
  Clock,
  Shield,
  BarChart3,
  FileText,
  Users,
  Globe,
  Database,
  Lock,
  CheckCircle,
  ExternalLink,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

// Animated counter hook
function useIntersection(ref: React.RefObject<Element | null>, options?: IntersectionObserverInit) {
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        el.classList.add('in-view');
        observer.disconnect();
      }
    }, options);
    observer.observe(el);
    return () => observer.disconnect();
  }, [ref, options]);
}

function FadeIn({ children, className, delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const ref = useRef<HTMLDivElement>(null);
  useIntersection(ref, { threshold: 0.1 });

  return (
    <div
      ref={ref}
      className={cn('opacity-0 translate-y-4 transition-all duration-500 ease-out [&.in-view]:opacity-100 [&.in-view]:translate-y-0', className)}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

const FEATURES = [
  {
    icon: Search,
    title: 'Search Intelligence',
    description:
      'Query across publicly available data sources. Correlate usernames, domains, IP addresses, email patterns, and organizational identifiers from a single interface.',
  },
  {
    icon: Users,
    title: 'Entity Intelligence',
    description:
      'Structure and visualize discovered entities with typed attributes, confidence indicators, and full source traceability for methodological transparency.',
  },
  {
    icon: GitBranch,
    title: 'Relationship Mapping',
    description:
      'Visualize connections between entities through an interactive graph. Understand association types, source attribution, and inferred relationships at a glance.',
  },
  {
    icon: Clock,
    title: 'Timeline Analysis',
    description:
      'Organize events chronologically across an investigation. Filter by entity, date range, and confidence level to reconstruct sequences from public records.',
  },
  {
    icon: Globe,
    title: 'Source Analysis',
    description:
      'Catalog every source with typed classification, access timestamps, and confidence assessments. Always know where information originated.',
  },
  {
    icon: Database,
    title: 'Evidence Management',
    description:
      'Attach evidence to entities and sources with optional content hashing for auditability. Every finding is traceable to its public origin.',
  },
  {
    icon: FileText,
    title: 'Case Management',
    description:
      'Organize work into structured investigations. Track status, priority, and progress across entities, sources, evidence, and timeline events.',
  },
  {
    icon: BarChart3,
    title: 'Report Generation',
    description:
      'Compile findings into structured reports with executive summaries, methodology documentation, and mandatory limitations disclosures.',
  },
];

const STATS = [
  { value: '100%', label: 'Public sources only' },
  { value: 'Zero', label: 'Private data access' },
  { value: 'Full', label: 'Source attribution' },
  { value: 'Built-in', label: 'Methodology transparency' },
];

// Mini dashboard preview component
function DashboardPreview() {
  return (
    <div className="relative rounded-2xl border border-border bg-background shadow-2xl overflow-hidden">
      {/* Window chrome */}
      <div className="flex items-center gap-2 border-b border-border px-4 py-3 bg-muted/30">
        <div className="h-2.5 w-2.5 rounded-full bg-red-400/60" />
        <div className="h-2.5 w-2.5 rounded-full bg-amber-400/60" />
        <div className="h-2.5 w-2.5 rounded-full bg-green-400/60" />
        <div className="ml-3 h-5 flex-1 rounded bg-muted/60 max-w-xs" />
      </div>

      {/* Dashboard layout */}
      <div className="flex h-64 lg:h-80">
        {/* Sidebar */}
        <div className="w-40 border-r border-border bg-muted/10 p-3 space-y-1">
          {['Overview', 'Investigations', 'Entities', 'Sources', 'Timeline', 'Graph'].map((item, i) => (
            <div
              key={item}
              className={cn(
                'h-7 rounded-lg px-2 flex items-center',
                i === 0 ? 'bg-foreground/90' : 'hover:bg-muted'
              )}
            >
              <span className={cn('text-xs', i === 0 ? 'text-background' : 'text-muted-foreground')}>
                {item}
              </span>
            </div>
          ))}
        </div>

        {/* Main content */}
        <div className="flex-1 p-4 space-y-3 overflow-hidden">
          {/* Stats row */}
          <div className="grid grid-cols-3 gap-2">
            {[
              { label: 'Investigations', val: '3' },
              { label: 'Entities', val: '14' },
              { label: 'Sources', val: '27' },
            ].map((stat) => (
              <div key={stat.label} className="rounded-lg border border-border bg-card p-2.5">
                <div className="text-xs text-muted-foreground">{stat.label}</div>
                <div className="text-lg font-semibold mt-0.5">{stat.val}</div>
              </div>
            ))}
          </div>

          {/* Recent items */}
          <div className="rounded-lg border border-border">
            <div className="px-3 py-2 border-b border-border">
              <span className="text-xs font-medium text-muted-foreground">Active Investigations</span>
            </div>
            {[
              { name: 'Nexarion Holdings Structure', status: 'Active', confidence: 'High' },
              { name: 'Domain Infrastructure — vortexlabs.io', status: 'Active', confidence: 'Med' },
              { name: 'Supply Chain Transparency', status: 'Active', confidence: 'High' },
            ].map((inv) => (
              <div key={inv.name} className="flex items-center justify-between px-3 py-2 border-b border-border/50 last:border-0">
                <span className="text-xs truncate flex-1 pr-2">{inv.name}</span>
                <span className="text-xs text-emerald-600 shrink-0 font-medium">{inv.status}</span>
              </div>
            ))}
          </div>

          {/* Graph preview */}
          <div className="rounded-lg border border-border bg-muted/20 p-3 flex items-center justify-center h-16">
            <div className="flex items-center gap-3 opacity-60">
              <div className="h-6 w-6 rounded-full border-2 border-foreground/40 flex items-center justify-center">
                <span className="text-[8px] font-bold">ORG</span>
              </div>
              <div className="h-px w-8 bg-foreground/20" />
              <div className="h-5 w-5 rounded-full border-2 border-blue-400/60 flex items-center justify-center">
                <span className="text-[7px]">DOM</span>
              </div>
              <div className="h-px w-8 bg-foreground/20" />
              <div className="h-5 w-5 rounded-full border-2 border-purple-400/60 flex items-center justify-center">
                <span className="text-[7px]">IP</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function LandingPage() {
  const heroRef = useRef<HTMLDivElement>(null);

  return (
    <main>
      {/* ── HERO ── */}
      <section
        ref={heroRef}
        className="relative min-h-[80vh] flex flex-col items-center justify-center px-4 pb-16 text-center"
        aria-labelledby="hero-heading"
      >
        {/* Subtle grid background */}
        <div
          className="pointer-events-none absolute inset-0 bg-[linear-gradient(to_right,hsl(var(--border))_1px,transparent_1px),linear-gradient(to_bottom,hsl(var(--border))_1px,transparent_1px)] bg-[size:4rem_4rem] opacity-30"
          aria-hidden="true"
        />
        <div
          className="pointer-events-none absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background"
          aria-hidden="true"
        />

        <div className="relative z-10 max-w-4xl mx-auto">
          <div className="mb-6 inline-flex">
            <Badge variant="secondary" className="gap-1.5 rounded-full py-1 px-3 text-xs">
              <Shield className="h-3 w-3" />
              Public sources only · Ethical OSINT framework
            </Badge>
          </div>

          <h1
            id="hero-heading"
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-semibold tracking-tight text-balance"
          >
            Open intelligence,{' '}
            <span className="text-muted-foreground">precisely structured.</span>
          </h1>

          <p className="mt-6 text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto text-balance leading-relaxed">
            BrokeBase is a professional OSINT workspace for organizing, correlating, and analyzing
            publicly available information. Built for researchers, journalists, and security professionals
            who demand methodological rigor.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
            <Link to="/app">
              <Button size="lg" className="w-full sm:w-auto rounded-xl gap-2">
                Launch BrokeBase
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <a href="#features">
              <Button variant="outline" size="lg" className="w-full sm:w-auto rounded-xl">
                Explore Platform
              </Button>
            </a>
          </div>

          <p className="mt-4 text-xs text-muted-foreground">
            No account required · Demo data · Open source principles
          </p>
        </div>
      </section>

      {/* ── PLATFORM PREVIEW ── */}
      <section
        id="platform"
        className="py-20 px-4"
        aria-labelledby="platform-heading"
      >
        <div className="max-w-5xl mx-auto">
          <FadeIn>
            <div className="text-center mb-10">
              <h2 id="platform-heading" className="text-2xl sm:text-3xl font-semibold tracking-tight">
                Professional intelligence workspace
              </h2>
              <p className="mt-3 text-muted-foreground text-sm sm:text-base max-w-xl mx-auto">
                Every component of BrokeBase is purpose-built for structured OSINT workflows,
                not repurposed from generic project management tools.
              </p>
            </div>
          </FadeIn>

          <FadeIn delay={100}>
            <DashboardPreview />
          </FadeIn>
        </div>
      </section>

      {/* ── STATS ── */}
      <section className="py-12 px-4 border-y border-border bg-muted/20" aria-label="Key principles">
        <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6">
          {STATS.map((stat, i) => (
            <FadeIn key={stat.label} delay={i * 80} className="text-center">
              <div className="text-2xl sm:text-3xl font-semibold">{stat.value}</div>
              <div className="text-xs sm:text-sm text-muted-foreground mt-1">{stat.label}</div>
            </FadeIn>
          ))}
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section
        id="features"
        className="py-20 px-4"
        aria-labelledby="features-heading"
      >
        <div className="max-w-5xl mx-auto">
          <FadeIn className="text-center mb-12">
            <h2 id="features-heading" className="text-2xl sm:text-3xl font-semibold tracking-tight">
              Built for every stage of investigation
            </h2>
            <p className="mt-3 text-muted-foreground text-sm sm:text-base max-w-xl mx-auto">
              From first search to final report, BrokeBase covers the complete OSINT research lifecycle
              with tools designed for professional workflows.
            </p>
          </FadeIn>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {FEATURES.map((feature, i) => (
              <FadeIn key={feature.title} delay={i * 50}>
                <article className="group rounded-xl border border-border bg-card p-5 h-full hover:border-foreground/20 hover:shadow-sm transition-all duration-200">
                  <div className="mb-3 flex h-9 w-9 items-center justify-center rounded-lg bg-muted group-hover:bg-foreground/5 transition-colors">
                    <feature.icon className="h-4 w-4 text-foreground" />
                  </div>
                  <h3 className="text-sm font-semibold mb-2">{feature.title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{feature.description}</p>
                </article>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── INTELLIGENCE ── */}
      <section
        id="intelligence"
        className="py-20 px-4 bg-muted/20 border-y border-border"
        aria-labelledby="intelligence-heading"
      >
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <FadeIn>
              <div>
                <h2 id="intelligence-heading" className="text-2xl sm:text-3xl font-semibold tracking-tight mb-4">
                  Inference is not fact.
                  <br />
                  <span className="text-muted-foreground">BrokeBase makes the difference visible.</span>
                </h2>
                <p className="text-muted-foreground text-sm leading-relaxed mb-6">
                  Every entity, relationship, and finding in BrokeBase carries a confidence indicator
                  and is linked to its originating public source. The platform deliberately distinguishes
                  between verified records, corroborated findings, inferences, and low-confidence observations.
                </p>
                <ul className="space-y-3" role="list">
                  {[
                    'Verified — confirmed from authoritative public records',
                    'High confidence — corroborated by multiple independent sources',
                    'Medium confidence — supported by a single source',
                    'Low confidence — inferential, requires further corroboration',
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-2.5 text-sm">
                      <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </FadeIn>
            <FadeIn delay={150}>
              <div className="space-y-3">
                {[
                  { label: 'Verified', width: 'w-full', color: 'bg-emerald-500' },
                  { label: 'High Confidence', width: 'w-4/5', color: 'bg-blue-500' },
                  { label: 'Medium Confidence', width: 'w-3/5', color: 'bg-amber-500' },
                  { label: 'Low Confidence', width: 'w-2/5', color: 'bg-red-400' },
                ].map((bar) => (
                  <div key={bar.label} className="space-y-1.5">
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">{bar.label}</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted">
                      <div className={cn('h-2 rounded-full transition-all', bar.color, bar.width)} />
                    </div>
                  </div>
                ))}
                <p className="text-xs text-muted-foreground pt-2">
                  Confidence is a methodological indicator, not a guarantee of accuracy.
                </p>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* ── SECURITY ── */}
      <section
        id="security"
        className="py-20 px-4"
        aria-labelledby="security-heading"
      >
        <div className="max-w-4xl mx-auto text-center">
          <FadeIn>
            <h2 id="security-heading" className="text-2xl sm:text-3xl font-semibold tracking-tight mb-3">
              Security-first architecture
            </h2>
            <p className="text-muted-foreground text-sm sm:text-base max-w-xl mx-auto mb-10">
              BrokeBase is designed with strict security controls, input validation, and data minimization
              principles. Every component is built to be auditable, transparent, and privacy-conscious.
            </p>
          </FadeIn>
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              {
                icon: Lock,
                title: 'Input Validation',
                description: 'All inputs validated and sanitized. No raw user data touches backend logic.',
              },
              {
                icon: Shield,
                title: 'Security Headers',
                description: 'Strict CSP, HSTS, X-Frame-Options, and Permissions-Policy headers configured.',
              },
              {
                icon: Database,
                title: 'Data Minimization',
                description: 'Collect only what is necessary. No unnecessary PII stored or transmitted.',
              },
            ].map((item, i) => (
              <FadeIn key={item.title} delay={i * 80}>
                <div className="rounded-xl border border-border p-5 text-left">
                  <item.icon className="h-5 w-5 mb-3 text-foreground" />
                  <h3 className="text-sm font-semibold mb-2">{item.title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{item.description}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-20 px-4 border-t border-border" aria-label="Get started">
        <div className="max-w-2xl mx-auto text-center">
          <FadeIn>
            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight mb-3">
              Ready to structure your intelligence?
            </h2>
            <p className="text-muted-foreground text-sm mb-8 max-w-md mx-auto">
              Launch BrokeBase and start organizing public intelligence with professional-grade tools.
              Demo data included — no configuration required.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link to="/app">
                <Button size="lg" className="w-full sm:w-auto rounded-xl gap-2">
                  Launch BrokeBase
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex"
              >
                <Button variant="outline" size="lg" className="w-full sm:w-auto rounded-xl gap-2">
                  View Documentation
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </a>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="border-t border-border py-10 px-4" role="contentinfo">
        <div className="max-w-5xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-foreground">
                <span className="text-background text-xs font-bold select-none">BB</span>
              </div>
              <span className="text-sm font-semibold">BrokeBase</span>
            </div>

            <nav aria-label="Footer navigation" className="flex flex-wrap gap-4 justify-center">
              {['Platform', 'Features', 'Security', 'Ethics', 'Documentation'].map((item) => (
                <a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className="text-xs text-muted-foreground hover:text-foreground transition-colors"
                >
                  {item}
                </a>
              ))}
            </nav>

            <p className="text-xs text-muted-foreground text-center">
              BrokeBase operates exclusively on public data sources.
              <br />
              For authorized research and investigative use only.
            </p>
          </div>
        </div>
      </footer>
    </main>
  );
}
