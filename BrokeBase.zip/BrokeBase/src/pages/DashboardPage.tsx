import { Link } from 'react-router-dom';
import {
  FolderOpen,
  Users,
  Globe,
  Database,
  ArrowRight,
  Plus,
  Clock,
  TrendingUp,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ConfidenceBadge } from '@/components/common/ConfidenceBadge';
import { AppHeader } from '@/components/navigation/AppHeader';
import { useAppStore } from '@/lib/store';

import { DEMO_STATS } from '@/data/mock';

function StatCard({
  icon: Icon,
  label,
  value,
  href,
}: {
  icon: React.ElementType;
  label: string;
  value: number;
  href: string;
}) {
  return (
    <Link to={href} className="block group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-xl">
      <Card className="group-hover:border-foreground/20 group-hover:shadow-sm transition-all duration-200">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted">
              <Icon className="h-4 w-4 text-foreground" />
            </div>
            <ArrowRight className="h-3.5 w-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
          <div className="text-2xl font-semibold">{value}</div>
          <div className="text-xs text-muted-foreground mt-1">{label}</div>
        </CardContent>
      </Card>
    </Link>
  );
}

export function DashboardPage() {
  const { investigations, entities, timeline } = useAppStore();
  const activeInvestigations = investigations.filter((i) => i.status === 'active');
  const recentEntities = [...entities].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 5);
  const recentTimeline = [...timeline].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 4);

  return (
    <>
      <AppHeader title="Overview" description="Intelligence workspace summary" />
      <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-6">
        {/* Demo notice */}
        <div className="rounded-xl border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/40 px-4 py-3 flex items-center gap-3" role="alert">
          <div className="h-2 w-2 rounded-full bg-amber-400 shrink-0" />
          <p className="text-xs text-amber-700 dark:text-amber-400">
            <strong>Demo Mode</strong> — All data shown is entirely synthetic and fictional.
            It does not represent any real individuals, organizations, or events.
          </p>
        </div>

        {/* Stats */}
        <div>
          <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">Workspace Summary</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <StatCard icon={FolderOpen} label="Active Investigations" value={DEMO_STATS.activeInvestigations} href="/app/investigations" />
            <StatCard icon={Users} label="Total Entities" value={DEMO_STATS.totalEntities} href="/app/entities" />
            <StatCard icon={Globe} label="Total Sources" value={DEMO_STATS.totalSources} href="/app/sources" />
            <StatCard icon={Database} label="Evidence Items" value={DEMO_STATS.totalEvidence} href="/app/evidence" />
          </div>
        </div>

        {/* Active investigations */}
        <div className="grid md:grid-cols-2 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-sm">Active Investigations</CardTitle>
              <Link to="/app/investigations">
                <Button variant="ghost" size="sm" className="text-xs gap-1 h-7">
                  View all <ArrowRight className="h-3 w-3" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent className="pt-0 space-y-2">
              {activeInvestigations.length === 0 ? (
                <div className="py-6 text-center">
                  <p className="text-xs text-muted-foreground mb-2">No active investigations</p>
                  <Link to="/app/investigations">
                    <Button variant="outline" size="sm" className="gap-1.5">
                      <Plus className="h-3.5 w-3.5" />
                      New Investigation
                    </Button>
                  </Link>
                </div>
              ) : (
                activeInvestigations.slice(0, 4).map((inv) => (
                  <Link
                    key={inv.id}
                    to={`/app/investigations/${inv.id}`}
                    className="flex items-center justify-between rounded-lg p-2.5 hover:bg-muted transition-colors group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate">{inv.title}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {inv.entityCount} entities · {inv.sourceCount} sources
                      </p>
                    </div>
                    <div className="flex items-center gap-2 ml-3 shrink-0">
                      <Badge variant={inv.priority === 'high' ? 'destructive' : inv.priority === 'medium' ? 'warning' : 'secondary'}>
                        {inv.priority}
                      </Badge>
                    </div>
                  </Link>
                ))
              )}
            </CardContent>
          </Card>

          {/* Recent entities */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-3">
              <CardTitle className="text-sm">Recent Entities</CardTitle>
              <Link to="/app/entities">
                <Button variant="ghost" size="sm" className="text-xs gap-1 h-7">
                  View all <ArrowRight className="h-3 w-3" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent className="pt-0 space-y-2">
              {recentEntities.length === 0 ? (
                <div className="py-6 text-center">
                  <p className="text-xs text-muted-foreground">No entities yet</p>
                </div>
              ) : (
                recentEntities.map((entity) => (
                  <Link
                    key={entity.id}
                    to={`/app/entities/${entity.id}`}
                    className="flex items-center gap-3 rounded-lg p-2.5 hover:bg-muted transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  >
                    <div className="h-7 w-7 rounded-lg bg-muted flex items-center justify-center shrink-0">
                      <span className="text-xs font-medium uppercase text-muted-foreground">
                        {entity.type.slice(0, 2)}
                      </span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate">{entity.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{entity.type}</p>
                    </div>
                    <ConfidenceBadge level={entity.confidence} />
                  </Link>
                ))
              )}
            </CardContent>
          </Card>
        </div>

        {/* Timeline */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Clock className="h-4 w-4 text-muted-foreground" />
              Recent Timeline Events
            </CardTitle>
            <Link to="/app/timeline">
              <Button variant="ghost" size="sm" className="text-xs gap-1 h-7">
                View timeline <ArrowRight className="h-3 w-3" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="pt-0">
            {recentTimeline.length === 0 ? (
              <div className="py-6 text-center">
                <p className="text-xs text-muted-foreground">No timeline events yet</p>
              </div>
            ) : (
              <ol className="relative pl-4 border-l border-border space-y-4" aria-label="Timeline events">
                {recentTimeline.map((event) => (
                  <li key={event.id} className="relative">
                    <div className="absolute -left-[17px] h-2 w-2 rounded-full bg-foreground/30 ring-2 ring-background mt-1" />
                    <p className="text-sm font-medium">{event.title}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-xs text-muted-foreground">
                        {new Date(event.date).getFullYear()}
                      </span>
                      <ConfidenceBadge level={event.confidence} />
                    </div>
                  </li>
                ))}
              </ol>
            )}
          </CardContent>
        </Card>

        {/* Quick actions */}
        <div>
          <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">Quick Actions</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'New Investigation', icon: Plus, href: '/app/investigations?new=true' },
              { label: 'Search Intelligence', icon: Globe, href: '/app/search' },
              { label: 'Add Entity', icon: Users, href: '/app/entities?new=true' },
              { label: 'View Graph', icon: TrendingUp, href: '/app/relationships' },
            ].map((action) => (
              <Link key={action.label} to={action.href}>
                <Button variant="outline" className="w-full h-auto py-3 flex-col gap-2 rounded-xl text-xs">
                  <action.icon className="h-4 w-4" />
                  {action.label}
                </Button>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
