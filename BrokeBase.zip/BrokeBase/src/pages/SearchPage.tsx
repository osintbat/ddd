import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Users, Globe, Database, FolderOpen, ArrowRight, AlertCircle } from 'lucide-react';
import { AppHeader } from '@/components/navigation/AppHeader';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ConfidenceBadge } from '@/components/common/ConfidenceBadge';
import { EntityTypeIcon } from '@/components/common/EntityTypeBadge';
import { useAppStore } from '@/lib/store';
import { sanitizeSearchQuery } from '@/lib/utils';
import type { SearchResult } from '@/types';

const TYPE_ICONS = {
  entity: Users,
  source: Globe,
  evidence: Database,
  investigation: FolderOpen,
};

const TYPE_HREFS: Record<string, string> = {
  entity: '/app/entities',
  source: '/app/sources',
  evidence: '/app/evidence',
  investigation: '/app/investigations',
};

export function SearchPage() {
  const { entities, sources, investigations } = useAppStore();
  const [query, setQuery] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);

  const handleSearch = () => {
    const q = sanitizeSearchQuery(query);
    if (!q || q.length < 2) return;
    setSubmitted(true);

    const ql = q.toLowerCase();
    const found: SearchResult[] = [];

    // Search entities
    entities.forEach((e) => {
      if (e.name.toLowerCase().includes(ql) || e.type.includes(ql) || e.description?.toLowerCase().includes(ql)) {
        found.push({
          type: 'entity',
          id: e.id,
          title: e.name,
          description: `${e.type} · ${e.confidence} confidence`,
          confidence: e.confidence,
          investigationId: e.investigationId,
        });
      }
    });

    // Search sources
    sources.forEach((s) => {
      if (s.title.toLowerCase().includes(ql) || s.domain.toLowerCase().includes(ql)) {
        found.push({
          type: 'source',
          id: s.id,
          title: s.title,
          description: s.domain,
          confidence: s.confidence,
          investigationId: s.investigationId,
        });
      }
    });

    // Search investigations
    investigations.forEach((inv) => {
      if (inv.title.toLowerCase().includes(ql) || inv.description?.toLowerCase().includes(ql)) {
        found.push({
          type: 'investigation',
          id: inv.id,
          title: inv.title,
          description: `${inv.status} · ${inv.entityCount} entities`,
        });
      }
    });

    setResults(found);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSearch();
  };

  const groupedResults = results.reduce<Record<string, SearchResult[]>>((acc, r) => {
    if (!acc[r.type]) acc[r.type] = [];
    acc[r.type].push(r);
    return acc;
  }, {});

  return (
    <>
      <AppHeader title="Search" description="Query your intelligence workspace" />
      <div className="p-4 sm:p-6 max-w-3xl mx-auto space-y-4">
        {/* Search bar */}
        <div className="flex gap-2">
          <Input
            icon={<Search className="h-4 w-4" />}
            placeholder="Search entities, sources, investigations…"
            value={query}
            onChange={(e) => { setQuery(e.target.value); setSubmitted(false); }}
            onKeyDown={handleKeyDown}
            maxLength={512}
            aria-label="Search intelligence workspace"
            className="flex-1 h-11 text-base"
          />
          <Button onClick={handleSearch} disabled={query.length < 2} size="lg">Search</Button>
        </div>

        {/* Search scope disclaimer */}
        <div className="flex gap-2 items-start rounded-lg border border-border bg-muted/20 px-4 py-3" role="note">
          <AlertCircle className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
          <p className="text-xs text-muted-foreground">
            <strong>Scope:</strong> This search queries only data within your local BrokeBase workspace —
            entities, sources, and evidence you have already recorded. It does not query external systems,
            the web, or any third-party APIs. All underlying data originates from publicly available sources.
          </p>
        </div>

        {/* Results */}
        {submitted && (
          <div className="space-y-4">
            {results.length === 0 ? (
              <div className="py-12 text-center">
                <Search className="h-8 w-8 text-muted-foreground mx-auto mb-3" />
                <p className="text-sm font-medium">No results found</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Try different search terms. Results are limited to your workspace data.
                </p>
              </div>
            ) : (
              <>
                <p className="text-xs text-muted-foreground">
                  {results.length} result{results.length !== 1 ? 's' : ''} for "{sanitizeSearchQuery(query)}"
                </p>

                {(['entity', 'investigation', 'source', 'evidence'] as const).map((type) => {
                  const group = groupedResults[type];
                  if (!group?.length) return null;
                  const Icon = TYPE_ICONS[type];
                  const labels = { entity: 'Entities', investigation: 'Investigations', source: 'Sources', evidence: 'Evidence' };
                  return (
                    <div key={type}>
                      <div className="flex items-center gap-2 mb-2">
                        <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                        <h2 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{labels[type]}</h2>
                        <Badge variant="secondary">{group.length}</Badge>
                      </div>
                      <div className="space-y-1.5">
                        {group.map((result) => {
                          const href = `${TYPE_HREFS[result.type]}/${result.id}`;
                          const entity = type === 'entity' ? entities.find((e) => e.id === result.id) : null;
                          return (
                            <Link
                              key={result.id}
                              to={href}
                              className="flex items-center gap-3 rounded-xl border border-border p-3 hover:border-foreground/20 hover:bg-muted/30 transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                            >
                              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted">
                                {entity ? <EntityTypeIcon type={entity.type} className="h-4 w-4" /> : <Icon className="h-4 w-4 text-muted-foreground" />}
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium truncate">{result.title}</p>
                                {result.description && (
                                  <p className="text-xs text-muted-foreground truncate">{result.description}</p>
                                )}
                              </div>
                              <div className="flex items-center gap-2 shrink-0">
                                {result.confidence && <ConfidenceBadge level={result.confidence} />}
                                <ArrowRight className="h-4 w-4 text-muted-foreground" />
                              </div>
                            </Link>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </>
            )}
          </div>
        )}

        {/* Supported query types */}
        {!submitted && (
          <Card>
            <CardContent className="p-5">
              <h3 className="text-sm font-medium mb-3">Supported search types</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {['Username', 'Domain', 'IP Address', 'Email', 'Organization', 'Person', 'URL', 'Keyword', 'Location'].map((type) => (
                  <div key={type} className="flex items-center gap-2 text-xs text-muted-foreground">
                    <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground shrink-0" />
                    {type}
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted-foreground mt-4 pt-3 border-t border-border">
                BrokeBase searches your recorded workspace data only. No external API calls are made during local search.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </>
  );
}
