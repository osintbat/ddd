import { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Plus, FolderOpen, Search, ArrowRight, Trash2, Archive } from 'lucide-react';
import { AppHeader } from '@/components/navigation/AppHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { EmptyState } from '@/components/common/EmptyState';
import { useAppStore } from '@/lib/store';
import { formatRelativeTime, generateId } from '@/lib/utils';
import { toast } from '@/hooks/useToast';
import type { Investigation, InvestigationStatus, Priority } from '@/types';

const STATUS_COLORS: Record<InvestigationStatus, 'default' | 'success' | 'secondary' | 'outline'> = {
  draft: 'secondary',
  active: 'success',
  archived: 'outline',
};

const PRIORITY_COLORS: Record<Priority, 'destructive' | 'warning' | 'secondary' | 'default'> = {
  critical: 'destructive',
  high: 'destructive',
  medium: 'warning',
  low: 'secondary',
};

function NewInvestigationDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { addInvestigation } = useAppStore();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');

  const handleSubmit = () => {
    if (!title.trim()) return;
    const inv: Investigation = {
      id: generateId(),
      title: title.trim().slice(0, 200),
      description: description.trim().slice(0, 1000),
      tags: [],
      status: 'draft',
      priority,
      entityCount: 0,
      sourceCount: 0,
      evidenceCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    addInvestigation(inv);
    toast({ title: 'Investigation created', variant: 'success' });
    setTitle('');
    setDescription('');
    setPriority('medium');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New Investigation</DialogTitle>
          <DialogDescription>Create a new OSINT investigation workspace.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="inv-title">Title <span className="text-destructive">*</span></label>
            <Input
              id="inv-title"
              placeholder="e.g. Corporate structure analysis"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={200}
              autoFocus
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="inv-desc">Description</label>
            <textarea
              id="inv-desc"
              placeholder="Brief description of the investigation scope..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              maxLength={1000}
              rows={3}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring placeholder:text-muted-foreground"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="inv-priority">Priority</label>
            <Select value={priority} onValueChange={(v) => setPriority(v as Priority)}>
              <SelectTrigger id="inv-priority">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!title.trim()}>Create Investigation</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function DeleteDialog({ inv, onClose }: { inv: Investigation; onClose: () => void }) {
  const { deleteInvestigation } = useAppStore();
  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Delete Investigation</DialogTitle>
          <DialogDescription>
            This will permanently delete <strong>{inv.title}</strong> and all associated data. This cannot be undone.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button
            variant="destructive"
            onClick={() => {
              deleteInvestigation(inv.id);
              toast({ title: 'Investigation deleted', variant: 'default' });
              onClose();
            }}
          >
            Delete
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function InvestigationsPage() {
  const { investigations, updateInvestigation } = useAppStore();
  const [searchParams] = useSearchParams();
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [newOpen, setNewOpen] = useState(searchParams.get('new') === 'true');
  const [deleteTarget, setDeleteTarget] = useState<Investigation | null>(null);

  const filtered = investigations.filter((inv) => {
    const matchQuery = !query || inv.title.toLowerCase().includes(query.toLowerCase());
    const matchStatus = statusFilter === 'all' || inv.status === statusFilter;
    return matchQuery && matchStatus;
  });

  return (
    <>
      <AppHeader title="Investigations" description="OSINT investigation workspaces" />
      <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-4">
        {/* Toolbar */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="flex-1">
            <Input
              icon={<Search className="h-4 w-4" />}
              placeholder="Search investigations…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search investigations"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-36" aria-label="Filter by status">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="archived">Archived</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={() => setNewOpen(true)} className="gap-2 shrink-0">
            <Plus className="h-4 w-4" />
            New Investigation
          </Button>
        </div>

        {/* List */}
        {filtered.length === 0 ? (
          <EmptyState
            icon={<FolderOpen className="h-6 w-6" />}
            title={query || statusFilter !== 'all' ? 'No results found' : 'No investigations yet'}
            description={
              query || statusFilter !== 'all'
                ? 'Try adjusting your search or filters.'
                : 'Create your first investigation to start organizing intelligence.'
            }
            action={
              !query && statusFilter === 'all' ? (
                <Button onClick={() => setNewOpen(true)} className="gap-2">
                  <Plus className="h-4 w-4" />
                  Create Investigation
                </Button>
              ) : undefined
            }
          />
        ) : (
          <div className="grid gap-3">
            {filtered.map((inv) => (
              <Card key={inv.id} className="hover:border-foreground/20 hover:shadow-sm transition-all duration-200">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <Link
                          to={`/app/investigations/${inv.id}`}
                          className="text-sm font-semibold hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
                        >
                          {inv.title}
                        </Link>
                        <Badge variant={STATUS_COLORS[inv.status]}>{inv.status}</Badge>
                        <Badge variant={PRIORITY_COLORS[inv.priority]}>{inv.priority}</Badge>
                      </div>
                      {inv.description && (
                        <p className="text-xs text-muted-foreground mb-2 line-clamp-2">{inv.description}</p>
                      )}
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>{inv.entityCount} entities</span>
                        <span>{inv.sourceCount} sources</span>
                        <span>{inv.evidenceCount} evidence</span>
                        <span>Updated {formatRelativeTime(inv.updatedAt)}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <Link to={`/app/investigations/${inv.id}`}>
                        <Button variant="ghost" size="icon" aria-label={`Open ${inv.title}`}>
                          <ArrowRight className="h-4 w-4" />
                        </Button>
                      </Link>
                      {inv.status !== 'archived' && (
                        <Button
                          variant="ghost"
                          size="icon"
                          aria-label="Archive investigation"
                          onClick={() => {
                            updateInvestigation(inv.id, { status: 'archived' });
                            toast({ title: 'Investigation archived', variant: 'default' });
                          }}
                        >
                          <Archive className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label="Delete investigation"
                        onClick={() => setDeleteTarget(inv)}
                      >
                        <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <NewInvestigationDialog open={newOpen} onClose={() => setNewOpen(false)} />
        {deleteTarget && <DeleteDialog inv={deleteTarget} onClose={() => setDeleteTarget(null)} />}
      </div>
    </>
  );
}
