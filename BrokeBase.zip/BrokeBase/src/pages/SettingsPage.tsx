import { Settings, Moon, Sun, Shield, Info, Trash2 } from 'lucide-react';
import { AppHeader } from '@/components/navigation/AppHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAppStore } from '@/lib/store';
import { toast } from '@/hooks/useToast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { useState } from 'react';

export function SettingsPage() {
  const { theme, setTheme, isDemoMode } = useAppStore();
  const [clearOpen, setClearOpen] = useState(false);

  return (
    <>
      <AppHeader title="Settings" description="Workspace preferences and configuration" />
      <div className="p-4 sm:p-6 max-w-2xl mx-auto space-y-4">

        {/* Appearance */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Sun className="h-4 w-4 text-muted-foreground" />
              Appearance
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium">Theme</p>
                <p className="text-xs text-muted-foreground">Choose between light and dark interface.</p>
              </div>
              <div className="flex rounded-lg border border-border overflow-hidden">
                <button
                  onClick={() => setTheme('light')}
                  className={`flex items-center gap-2 px-3 py-2 text-xs transition-colors ${theme === 'light' ? 'bg-foreground text-background' : 'hover:bg-muted text-muted-foreground'}`}
                  aria-label="Light theme"
                  aria-pressed={theme === 'light'}
                >
                  <Sun className="h-3.5 w-3.5" />Light
                </button>
                <button
                  onClick={() => setTheme('dark')}
                  className={`flex items-center gap-2 px-3 py-2 text-xs transition-colors ${theme === 'dark' ? 'bg-foreground text-background' : 'hover:bg-muted text-muted-foreground'}`}
                  aria-label="Dark theme"
                  aria-pressed={theme === 'dark'}
                >
                  <Moon className="h-3.5 w-3.5" />Dark
                </button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Data */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Settings className="h-4 w-4 text-muted-foreground" />
              Data & Workspace
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-3">
            <div className="flex items-center justify-between py-2 border-b border-border">
              <div>
                <p className="text-sm font-medium">Demo Mode</p>
                <p className="text-xs text-muted-foreground">Workspace shows synthetic demonstration data.</p>
              </div>
              <Badge variant={isDemoMode ? 'warning' : 'success'}>{isDemoMode ? 'Active' : 'Disabled'}</Badge>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-destructive">Reset Workspace</p>
                <p className="text-xs text-muted-foreground">Clear all user-added data. Demo data will remain.</p>
              </div>
              <Button variant="outline" size="sm" onClick={() => setClearOpen(true)} className="text-destructive border-destructive/30 hover:bg-destructive/5">
                <Trash2 className="h-3.5 w-3.5 mr-1.5" />Reset
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Security */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Shield className="h-4 w-4 text-muted-foreground" />
              Security
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-2">
            {[
              { label: 'Input sanitization', status: 'Active', description: 'All user input is sanitized before processing.' },
              { label: 'URL validation', status: 'Active', description: 'Private/internal URLs are blocked from source entries.' },
              { label: 'XSS protection', status: 'Active', description: 'React handles output encoding automatically.' },
              { label: 'SSRF protection', status: 'Active', description: 'Private IP ranges are blocked from source URLs.' },
            ].map((item) => (
              <div key={item.label} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                <div>
                  <p className="text-sm font-medium">{item.label}</p>
                  <p className="text-xs text-muted-foreground">{item.description}</p>
                </div>
                <Badge variant="success">{item.status}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Keyboard shortcuts */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Keyboard Shortcuts</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-2">
              {[
                { keys: ['⌘', 'K'], label: 'Open command palette' },
                { keys: ['ESC'], label: 'Close modal / palette' },
              ].map((shortcut) => (
                <div key={shortcut.label} className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{shortcut.label}</span>
                  <div className="flex gap-1">
                    {shortcut.keys.map((k) => (
                      <kbd key={k} className="rounded border border-border bg-muted px-1.5 py-0.5 text-xs font-mono">{k}</kbd>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* About */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Info className="h-4 w-4 text-muted-foreground" />
              About BrokeBase
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 space-y-2 text-xs text-muted-foreground">
            <p>BrokeBase is a professional OSINT workspace for organizing publicly available intelligence. It operates exclusively on public data sources and is designed for authorized research, journalism, and security work.</p>
            <p>All demo data is entirely synthetic and does not represent real individuals, organizations, or events.</p>
            <div className="pt-2 border-t border-border flex gap-4">
              <span>Version 1.0.0</span>
              <a href="#" className="hover:text-foreground transition-colors">Security Policy</a>
              <a href="#" className="hover:text-foreground transition-colors">Ethics</a>
            </div>
          </CardContent>
        </Card>

        {/* Reset confirmation */}
        <Dialog open={clearOpen} onOpenChange={setClearOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Reset Workspace</DialogTitle>
              <DialogDescription>This will clear all user-added investigations, entities, sources, and evidence. Demo data will reload. This cannot be undone.</DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setClearOpen(false)}>Cancel</Button>
              <Button variant="destructive" onClick={() => {
                toast({ title: 'Workspace reset', description: 'User data cleared. Reload to see demo data.', variant: 'default' });
                setClearOpen(false);
              }}>Reset Workspace</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}
