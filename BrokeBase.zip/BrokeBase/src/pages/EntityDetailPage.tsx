import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Globe, Clock, Database } from 'lucide-react';
import { AppHeader } from '@/components/navigation/AppHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ConfidenceBadge } from '@/components/common/ConfidenceBadge';
import { EntityTypeBadge, EntityTypeIcon } from '@/components/common/EntityTypeBadge';
import { EmptyState } from '@/components/common/EmptyState';
import { useAppStore } from '@/lib/store';
import { formatDate, formatRelativeTime } from '@/lib/utils';

export function EntityDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { entities, sources, evidence, timeline, relationships } = useAppStore();

  const entity = entities.find((e) => e.id === id);
  if (!entity) {
    return (
      <>
        <AppHeader title="Entity not found" />
        <div className="p-6">
          <EmptyState
            title="Entity not found"
            description="This entity may have been deleted."
            action={<Button onClick={() => navigate('/app/entities')}>Back to entities</Button>}
          />
        </div>
      </>
    );
  }

  const relatedRelationships = relationships.filter(
    (r) => r.sourceEntityId === id || r.targetEntityId === id
  );
  const relatedEntityIds = relatedRelationships.map((r) =>
    r.sourceEntityId === id ? r.targetEntityId : r.sourceEntityId
  );
  const relatedEntities = entities.filter((e) => relatedEntityIds.includes(e.id));
  const entitySources = sources.filter((s) => entity.sources.includes(s.id));
  const entityEvidence = evidence.filter((ev) => ev.entityIds.includes(id!));
  const entityTimeline = timeline.filter((t) => t.entityIds.includes(id!));

  return (
    <>
      <AppHeader title={entity.name} description={`${entity.type} · ${entity.confidence} confidence`} />
      <div className="p-4 sm:p-6 max-w-5xl mx-auto space-y-4">
        {/* Back */}
        <Button variant="ghost" size="sm" onClick={() => navigate('/app/entities')} className="gap-1.5">
          <ArrowLeft className="h-4 w-4" /> Back to entities
        </Button>

        {/* Header card */}
        <Card>
          <CardContent className="p-5">
            <div className="flex items-start gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-muted">
                <EntityTypeIcon type={entity.type} className="h-5 w-5" />
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="text-lg font-semibold truncate">{entity.name}</h2>
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  <EntityTypeBadge type={entity.type} />
                  <ConfidenceBadge level={entity.confidence} />
                  {entity.tags.map((tag) => (
                    <Badge key={tag} variant="outline">{tag}</Badge>
                  ))}
                </div>
                {entity.description && (
                  <p className="text-sm text-muted-foreground mt-2">{entity.description}</p>
                )}
              </div>
              <div className="text-right text-xs text-muted-foreground shrink-0 hidden sm:block">
                <p>Created {formatDate(entity.createdAt)}</p>
                <p>Updated {formatRelativeTime(entity.updatedAt)}</p>
              </div>
            </div>

            {/* Metadata */}
            {Object.keys(entity.metadata).length > 0 && (
              <div className="mt-4 pt-4 border-t border-border grid grid-cols-2 sm:grid-cols-3 gap-3">
                {Object.entries(entity.metadata)
                  .filter(([, v]) => typeof v === 'string' || typeof v === 'number')
                  .map(([key, value]) => (
                    <div key={key}>
                      <p className="text-xs text-muted-foreground capitalize">{key.replace(/_/g, ' ')}</p>
                      <p className="text-sm font-medium">{String(value)}</p>
                    </div>
                  ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: 'Sources', value: entitySources.length, icon: Globe },
            { label: 'Evidence', value: entityEvidence.length, icon: Database },
            { label: 'Timeline events', value: entityTimeline.length, icon: Clock },
          ].map((s) => (
            <Card key={s.label}>
              <CardContent className="p-4 flex items-center gap-3">
                <s.icon className="h-4 w-4 text-muted-foreground" />
                <div>
                  <div className="text-xl font-semibold">{s.value}</div>
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {/* Related entities */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Related Entities ({relatedEntities.length})</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {relatedEntities.length === 0 ? (
                <p className="text-xs text-muted-foreground py-4 text-center">No related entities discovered yet.</p>
              ) : (
                <div className="space-y-2">
                  {relatedEntities.map((rel) => {
                    const relationship = relatedRelationships.find(
                      (r) => r.sourceEntityId === rel.id || r.targetEntityId === rel.id
                    );
                    return (
                      <Link
                        key={rel.id}
                        to={`/app/entities/${rel.id}`}
                        className="flex items-center gap-3 rounded-lg p-2 hover:bg-muted transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      >
                        <EntityTypeIcon type={rel.type} />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{rel.name}</p>
                          {relationship && (
                            <p className="text-xs text-muted-foreground capitalize">
                              {relationship.type.replace(/_/g, ' ')}
                            </p>
                          )}
                        </div>
                        <ConfidenceBadge level={rel.confidence} />
                      </Link>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Sources */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Sources ({entitySources.length})</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {entitySources.length === 0 ? (
                <p className="text-xs text-muted-foreground py-4 text-center">No sources linked to this entity.</p>
              ) : (
                <div className="space-y-2">
                  {entitySources.map((src) => (
                    <div key={src.id} className="flex items-start gap-2.5 rounded-lg p-2 border border-border">
                      <Globe className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{src.title}</p>
                        <p className="text-xs text-muted-foreground truncate">{src.domain}</p>
                        <p className="text-xs text-muted-foreground">Accessed {formatDate(src.accessedDate)}</p>
                      </div>
                      <ConfidenceBadge level={src.confidence} />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Timeline */}
        {entityTimeline.length > 0 && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Timeline ({entityTimeline.length})</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <ol className="relative pl-5 border-l border-border space-y-4" aria-label="Entity timeline">
                {entityTimeline
                  .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                  .map((event) => (
                    <li key={event.id} className="relative">
                      <div className="absolute -left-[18px] h-2 w-2 rounded-full bg-foreground/30 ring-2 ring-background mt-1" />
                      <time className="text-xs text-muted-foreground" dateTime={event.date}>
                        {formatDate(event.date)}
                      </time>
                      <p className="text-sm font-medium mt-0.5">{event.title}</p>
                      {event.description && (
                        <p className="text-xs text-muted-foreground">{event.description}</p>
                      )}
                    </li>
                  ))}
              </ol>
            </CardContent>
          </Card>
        )}

        {/* Methodological disclaimer */}
        <div className="rounded-xl border border-border bg-muted/20 px-4 py-3" role="note">
          <p className="text-xs text-muted-foreground">
            <strong>Methodology note:</strong> Confidence indicators reflect the quality and quantity of public sources
            corroborating this entity, not a guarantee of accuracy. All data originates from publicly available sources.
            Verify independently before drawing conclusions.
          </p>
        </div>
      </div>
    </>
  );
}
