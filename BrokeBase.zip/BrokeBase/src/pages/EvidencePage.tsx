import { useState } from 'react';
import { Plus, Database, Search, ExternalLink, Trash2 } from 'lucide-react';
import { AppHeader } from '@/components/navigation/AppHeader';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { ConfidenceBadge } from '@/components/common/ConfidenceBadge';
import { EmptyState } from '@/components/common/EmptyState';
import { useAppStore } from '@/lib/store';
import { formatDateTime, generateId, extractDomain, isValidUrl } from '@/lib/utils';
import { toast } from '@/hooks/useToast';
import type { Evidence, ConfidenceLevel } from '@/types';

function AddEvidenceDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { addEvidence, sources, investigations } = useAppStore();
  const [url, setUrl] = useState('');
  const [sourceId, setSourceId] = useState('');
  const [snippet, setSnippet] = useState('');
  const [notes, setNotes] = useState('');
  const [confidence, setConfidence] = useState<ConfidenceLevel>('medium');
  const [investigationId, setInvestigationId] = useState('');
  const [urlError, setUrlError] = useState('');

  const handleSubmit = () => {
    if (!url.trim()) return;
    if (!isValidUrl(url)) { setUrlError('Valid https:// URL required.'); return; }
    const hostname = new URL(url).hostname;
    if (/^(localhost|127\.|0\.0\.0\.0|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/i.test(hostname)) {
      setUrlError('Private URLs are not allowed.'); return;
    }
    const ev: Evidence = {
      id: generateId(),
      sourceId: sourceId || '',
      url: url.trim(),
      timestamp: new Date().toISOString(),
      snippet: snippet.trim().slice(0, 500) || undefined,
      notes: notes.trim().slice(0, 1000) || undefined,
      confidence,
      entityIds: [],
      investigationId: investigationId || undefined,
      createdAt: new Date().toISOString(),
    };
    addEvidence(ev);
    toast({ title: 'Evidence recorded', variant: 'success' });
    setUrl(''); setSourceId(''); setSnippet(''); setNotes(''); setUrlError(''); setInvestigationId('');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Record Evidence</DialogTitle>
          <DialogDescription>Record a piece of public evidence. All evidence must originate from publicly accessible sources.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="ev-url">Source URL <span className="text-destructive">*</span></label>
            <Input id="ev-url" type="url" placeholder="https://public-source.example/page" value={url}
              onChange={(e) => { setUrl(e.target.value); setUrlError(''); }} />
            {urlError && <p className="text-xs text-destructive">{urlError}</p>}
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium">Link to Source</label>
            <Select value={sourceId} onValueChange={setSourceId}>
              <SelectTrigger><SelectValue placeholder="Select catalogued source" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="">None</SelectItem>
                {sources.map((s) => <SelectItem key={s.id} value={s.id}>{s.title}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="ev-snippet">Snippet</label>
            <textarea id="ev-snippet" placeholder="Brief excerpt from the public source (optional)..." value={snippet}
              onChange={(e) => setSnippet(e.target.value)} maxLength={500} rows={2}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring placeholder:text-muted-foreground" />
            <p className="text-xs text-muted-foreground">Max 500 characters. Do not reproduce copyrighted material.</p>
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium" htmlFor="ev-notes">Notes</label>
            <textarea id="ev-notes" placeholder="Your analysis notes..." value={notes}
              onChange={(e) => setNotes(e.target.value)} maxLength={1000} rows={2}
              className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring placeholder:text-muted-foreground" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Confidence</label>
              <Select value={confidence} onValueChange={(v) => setConfidence(v as ConfidenceLevel)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="verified">Verified</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Investigation</label>
              <Select value={investigationId} onValueChange={setInvestigationId}>
                <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="">None</SelectItem>
                  {investigations.filter(i => i.status !== 'archived').map((i) => <SelectItem key={i.id} value={i.id}>{i.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={!url.trim()}>Record Evidence</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function EvidencePage() {
  const { evidence, deleteEvidence, sources } = useAppStore();
  const [query, setQuery] = useState('');
  const [confidenceFilter, setConfidenceFilter] = useState('all');
  const [newOpen, setNewOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Evidence | null>(null);

  const filtered = evidence.filter((ev) => {
    const src = sources.find((s) => s.id === ev.sourceId);
    const matchQuery = !query ||
      extractDomain(ev.url).toLowerCase().includes(query.toLowerCase()) ||
      (ev.snippet?.toLowerCase().includes(query.toLowerCase())) ||
      (src?.title.toLowerCase().includes(query.toLowerCase()));
    const matchConf = confidenceFilter === 'all' || ev.confidence === confidenceFilter;
    return matchQuery && matchConf;
  });

  return (
    <>
      <AppHeader title="Evidence" description="Source-backed evidence records" />
      <div className="p-4 sm:p-6 max-w-6xl mx-auto space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          <Input icon={<Search className="h-4 w-4" />} placeholder="Search evidence…" value={query} onChange={(e) => setQuery(e.target.value)} className="flex-1" />
          <Select value={confidenceFilter} onValueChange={setConfidenceFilter}>
            <SelectTrigger className="w-full sm:w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All confidence</SelectItem>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="verified">Verified</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={() => setNewOpen(true)} className="gap-2 shrink-0">
            <Plus className="h-4 w-4" />Record Evidence
          </Button>
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            icon={<Database className="h-6 w-6" />}
            title={query || confidenceFilter !== 'all' ? 'No evidence found' : 'No evidence recorded'}
            description="Record public-source evidence items linked to your investigations."
            action={!query && confidenceFilter === 'all' ? <Button onClick={() => setNewOpen(true)} className="gap-2"><Plus className="h-4 w-4" />Record Evidence</Button> : undefined}
          />
        ) : (
          <div className="space-y-2">
            {filtered.map((ev) => {
              const linkedSrc = sources.find((s) => s.id === ev.sourceId);
              return (
                <Card key={ev.id} className="hover:border-foreground/20 transition-all">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-muted mt-0.5">
                        <Database className="h-3.5 w-3.5 text-muted-foreground" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <span className="text-xs font-medium text-muted-foreground">{extractDomain(ev.url)}</span>
                          <ConfidenceBadge level={ev.confidence} />
                        </div>
                        {ev.snippet && (
                          <blockquote className="text-sm text-muted-foreground border-l-2 border-border pl-3 my-2 italic line-clamp-3">
                            {ev.snippet}
                          </blockquote>
                        )}
                        {ev.notes && <p className="text-xs text-muted-foreground">{ev.notes}</p>}
                        {linkedSrc && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Source: <span className="font-medium">{linkedSrc.title}</span>
                          </p>
                        )}
                        <p className="text-xs text-muted-foreground mt-1">{formatDateTime(ev.timestamp)}</p>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        <a href={ev.url} target="_blank" rel="noopener noreferrer">
                          <Button variant="ghost" size="icon" aria-label="Open URL">
                            <ExternalLink className="h-4 w-4" />
                          </Button>
                        </a>
                        <Button variant="ghost" size="icon" aria-label="Delete evidence" onClick={() => setDeleteTarget(ev)}>
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        <AddEvidenceDialog open={newOpen} onClose={() => setNewOpen(false)} />
        {deleteTarget && (
          <Dialog open onOpenChange={() => setDeleteTarget(null)}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Delete Evidence</DialogTitle>
                <DialogDescription>Delete this evidence record? This cannot be undone.</DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
                <Button variant="destructive" onClick={() => { deleteEvidence(deleteTarget.id); toast({ title: 'Evidence deleted' }); setDeleteTarget(null); }}>Delete</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </>
  );
}
