# Contributing to BrokeBase

## Development Setup

```bash
git clone <repo>
cd BrokeBase
npm install
npm run dev
```

## Code Standards

- **TypeScript strict mode** — no `any`, all types explicit
- **ESLint** — run `npm run lint` before committing
- **Prettier** — run `npm run format` before committing
- **Tests** — add tests for new utility functions

## Pull Request Process

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Make changes following code standards
4. Run the full check suite: `npm run typecheck && npm run lint && npm run test && npm run build`
5. Submit a pull request with a clear description

## Security

If you discover a security vulnerability, please do NOT open a public issue.
Contact the maintainers privately with details.

## Ethics

All contributions must comply with the [ETHICS.md](./ETHICS.md) policy.
No features that enable unauthorized access, credential theft, or privacy violations will be accepted.

## Commit Messages

Use conventional commit format:
- `feat:` new feature
- `fix:` bug fix
- `security:` security fix
- `docs:` documentation
- `test:` tests
- `refactor:` code refactor
