# BrokeBase — Professional OSINT Intelligence Platform

BrokeBase is a security-first workspace for organizing, correlating, and analyzing
intelligence from publicly available sources. Built for researchers, journalists,
and security professionals who require methodological rigor and full source attribution.

> **Demo Mode**: All data is entirely synthetic and fictional.

## Stack

- React 18 + TypeScript (strict) + Vite
- Tailwind CSS v4
- Radix UI primitives
- Zustand state management
- React Router v6
- Vitest + Testing Library
- cmdk command palette

## Quick Start

    npm install
    npm run dev

Production build:

    npm run build
    npm run preview

## Scripts

| Script | Description |
|--------|-------------|
| `npm run dev` | Development server |
| `npm run build` | TypeScript check + Vite build |
| `npm run typecheck` | Strict TS check |
| `npm run lint` | ESLint |
| `npm run format` | Prettier |
| `npm run test` | Run tests (44 tests) |
| `npm run audit` | npm security audit |

## Routes

- `/` — Landing page
- `/app` — Dashboard
- `/app/search` — Search
- `/app/investigations` — Investigations
- `/app/entities` — Entities
- `/app/sources` — Sources
- `/app/evidence` — Evidence
- `/app/timeline` — Timeline
- `/app/relationships` — Relationship graph
- `/app/reports` — Reports
- `/app/settings` — Settings

## Security

See SECURITY.md for 200+ security controls.
Key: input sanitization, SSRF prevention, XSS protection, strict TypeScript.

## Ethics

See ETHICS.md. For authorized research on public data only.

## Demo Data

All demo entities, names, domains, and identifiers are entirely fictional
and clearly labeled [DEMO]. They do not represent real individuals or organizations.
