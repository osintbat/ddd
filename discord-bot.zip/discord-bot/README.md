# Advanced Security Discord Bot

Bot Discord in Node.js (discord.js v14) bloccato su una singola guild, con
antinuke, antispam, sistema ticket e comandi slash sincronizzati automaticamente
ad ogni avvio.

## Cosa fa

- **Guild-lock**: funziona SOLO sulla guild `1537086580815044719`. Se qualcuno
  invita il bot in un altro server, il bot esce subito e ignora ogni interazione.
- **Comandi slash sincronizzati automaticamente**: ogni volta che avvii il bot,
  i comandi vengono ri-registrati sulla guild. Se modifichi/aggiungi comandi nel
  codice, basta riavviare il bot (systemctl restart) e sono subito aggiornati.
- **Risposte sempre ephemeral** dove opportuno: solo chi ha lanciato il comando
  vede la risposta (le risposte ai comandi di configurazione sono "visibili solo a te").
- **Embed bianchi in inglese** su tutte le risposte.
- **/antinuke**: se abilitato, appena un bot entra viene "osservato". Se quel
  bot crea un canale o invia un messaggio, il bot E chi lo ha invitato vengono
  bannati. Se un membro crea un webhook, il webhook viene eliminato e il
  membro kickato.
- **Antispam**: se un utente invia 3+ messaggi in meno di 3 secondi, i messaggi
  vengono eliminati e l'utente riceve un timeout di 1 minuto.
- **/ticketpanel**: invia un embed con un menu a tendina (Technical Support /
  Purchase a Plan). Aprendo un ticket viene creato un canale
  `ticket-nomeutente` nella categoria `1537090319332540476`.
- **/help**: elenco di tutti i comandi.

## Permessi che il bot deve avere sul server (ruolo del bot)

Per funzionare correttamente il ruolo del bot deve avere, come minimo:

- Ban Members
- Kick Members
- Moderate Members (per i timeout)
- Manage Channels
- Manage Webhooks
- View Audit Log
- Manage Roles (il ruolo del bot deve stare SOPRA i ruoli che deve poter gestire)
- Send Messages / Embed Links / Read Message History

Consiglio: dai al bot un ruolo dedicato posizionato in alto nella lista ruoli
(subito sotto i tuoi ruoli admin), NON necessariamente "Administrator", ma se
vuoi il massimo controllo puoi anche usare Administrator.

## Sicurezza inclusa "di fabbrica"

- Il token va SOLO nel file `.env`, mai committato (`.gitignore` lo esclude già).
- Il bot ignora e rifiuta ogni interazione proveniente da guild diverse da quella
  autorizzata, anche se per qualche motivo non riuscisse a lasciarla subito.
- I comandi di configurazione (`/antinuke`, `/ticketpanel`) richiedono permesso
  Administrator su Discord (`setDefaultMemberPermissions`), quindi anche se
  qualcuno vede il comando nella lista, Discord stesso blocca l'esecuzione se
  non ha i permessi.
- Nessuna azione distruttiva avviene senza controllo dell'audit log per capire
  con certezza chi ha eseguito l'azione sospetta.

## Installazione manuale (senza systemd)

```bash
npm install
cp .env.example .env
# modifica .env con il tuo DISCORD_TOKEN e CLIENT_ID
npm start
```

## Installazione automatica su VPS Ubuntu 24.04 (systemd, background)

Nello zip trovi `setup.py`. Esegui:

```bash
python3 setup.py
```

Lo script ti chiederà token, client id, e la cartella di destinazione, poi:
1. Copia il progetto in `/opt/discord-bot` (o dove scegli tu)
2. Crea il file `.env`
3. Installa Node.js (se assente) e le dipendenze npm
4. Crea un service `systemd` (`discord-bot.service`)
5. Abilita l'avvio automatico al boot e avvia il bot subito

Comandi utili dopo l'installazione:

```bash
sudo systemctl status discord-bot     # stato del bot
sudo systemctl restart discord-bot    # riavvia (risincronizza anche i comandi)
sudo journalctl -u discord-bot -f     # log in tempo reale
```
