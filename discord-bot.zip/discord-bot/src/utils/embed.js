const { EmbedBuilder } = require('discord.js');
const { EMBED_COLOR } = require('../config');

/**
 * Crea un embed bianco standard, in inglese.
 * @param {Object} opts
 * @param {string} [opts.title]
 * @param {string} [opts.description]
 * @param {Array}  [opts.fields]
 * @param {string} [opts.footer]
 */
function baseEmbed({ title, description, fields, footer } = {}) {
  const embed = new EmbedBuilder().setColor(EMBED_COLOR).setTimestamp();
  if (title) embed.setTitle(title);
  if (description) embed.setDescription(description);
  if (fields) embed.addFields(fields);
  embed.setFooter({ text: footer || 'Security System' });
  return embed;
}

function successEmbed(title, description) {
  return baseEmbed({ title: `✅ ${title}`, description });
}

function errorEmbed(title, description) {
  return baseEmbed({ title: `❌ ${title}`, description });
}

function infoEmbed(title, description) {
  return baseEmbed({ title: `ℹ️ ${title}`, description });
}

module.exports = { baseEmbed, successEmbed, errorEmbed, infoEmbed };
