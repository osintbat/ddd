const store = require('./store');
const { errorEmbed } = require('./embed');

/**
 * Banna il bot sospetto e chi lo ha invitato, in seguito a un'azione pericolosa
 * (creazione canale, invio messaggio subito dopo l'ingresso, ecc).
 */
async function punishNukeAttempt(guild, botId, inviterId, reason) {
  // Evita doppie esecuzioni per lo stesso bot
  if (!store.watchedBots.has(botId)) return;
  store.watchedBots.delete(botId);

  const logChannel = guild.systemChannel;

  try {
    await guild.members.ban(botId, { reason: `Antinuke: suspicious bot - ${reason}` });
  } catch (err) {
    console.error(`[Antinuke] Failed to ban bot ${botId}:`, err.message);
  }

  try {
    await guild.members.ban(inviterId, { reason: `Antinuke: invited a bot that performed - ${reason}` });
  } catch (err) {
    console.error(`[Antinuke] Failed to ban inviter ${inviterId}:`, err.message);
  }

  if (logChannel) {
    logChannel
      .send({
        embeds: [
          errorEmbed(
            'Antinuke Triggered',
            `A bot (<@${botId}>) was banned for ${reason}.\nThe inviter (<@${inviterId}>) has also been banned.`,
          ),
        ],
      })
      .catch(() => {});
  }
}

/**
 * Elimina un webhook creato da un membro e kicka chi lo ha creato.
 */
async function punishWebhookCreation(guild, webhookId, creatorId, webhookChannel) {
  const logChannel = guild.systemChannel;

  try {
    const webhooks = await webhookChannel.fetchWebhooks();
    const hook = webhooks.get(webhookId);
    if (hook) await hook.delete('Antinuke: unauthorized webhook creation');
  } catch (err) {
    console.error('[Antinuke] Failed to delete webhook:', err.message);
  }

  try {
    const member = await guild.members.fetch(creatorId);
    await member.kick('Antinuke: created a webhook');
  } catch (err) {
    console.error('[Antinuke] Failed to kick webhook creator:', err.message);
  }

  if (logChannel) {
    logChannel
      .send({
        embeds: [
          errorEmbed(
            'Antinuke Triggered',
            `A webhook created by <@${creatorId}> in ${webhookChannel} was deleted and the member was kicked.`,
          ),
        ],
      })
      .catch(() => {});
  }
}

module.exports = { punishNukeAttempt, punishWebhookCreation };
