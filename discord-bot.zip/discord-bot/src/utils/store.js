// Stato condiviso in memoria (semplice, senza database, come richiesto: "super avanzato" ma leggero)

module.exports = {
  // Se l'antinuke è attivo (settato via /antinuke)
  antinukeEnabled: false,

  // Map<botUserId, { inviterId: string, addedAt: number }>
  watchedBots: new Map(),

  // Map<userId, number[]> timestamp degli ultimi messaggi per antispam
  spamTracker: new Map(),

  // Ticket counter per naming univoco se serve
  ticketCounter: 0,
};
