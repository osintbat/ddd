const { REST, Routes } = require('discord.js');
const { TOKEN, CLIENT_ID, GUILD_ID } = require('./config');

/**
 * Registra (sincronizza) tutti i comandi slash SOLO sulla guild GUILD_ID.
 * Viene eseguito automaticamente ad ogni avvio del bot, quindi se aggiungi
 * o modifichi un comando nel codice, basta riavviare il bot per aggiornarlo:
 * niente bisogno di script separati o attese di propagazione globale.
 */
async function deployCommands(commandsCollection) {
  const rest = new REST({ version: '10' }).setToken(TOKEN);
  const body = [...commandsCollection.values()].map((c) => c.data.toJSON());

  try {
    console.log(`[Commands] Syncing ${body.length} slash command(s) to guild ${GUILD_ID}...`);
    await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body });
    console.log('[Commands] Sync complete.');
  } catch (err) {
    console.error('[Commands] Failed to sync commands:', err);
  }
}

module.exports = { deployCommands };
