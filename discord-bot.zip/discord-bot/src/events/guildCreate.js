const { Events } = require('discord.js');
const { GUILD_ID } = require('../config');
const { errorEmbed } = require('../utils/embed');

module.exports = {
  name: Events.GuildCreate,
  async execute(guild) {
    if (guild.id === GUILD_ID) return; // guild autorizzata, tutto ok

    console.log(`[GuildLock] Bot invited to unauthorized guild: ${guild.name} (${guild.id}). Leaving...`);

    // Prova ad avvisare prima di uscire (best effort)
    try {
      const channel = guild.channels.cache.find(
        (c) => c.isTextBased() && c.permissionsFor(guild.members.me)?.has('SendMessages'),
      );
      if (channel) {
        await channel.send({
          embeds: [
            errorEmbed(
              'Unauthorized Server',
              'This bot is locked to a single specific server and is not available for public use. Leaving now.',
            ),
          ],
        });
      }
    } catch (err) {
      // ignora, non è critico
    }

    await guild.leave();
  },
};
