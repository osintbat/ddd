const { Events } = require('discord.js');
const { deployCommands } = require('../deploy-commands');
const { GUILD_ID } = require('../config');

module.exports = {
  name: Events.ClientReady,
  once: true,
  async execute(client) {
    console.log(`[Ready] Logged in as ${client.user.tag}`);

    // Sincronizza sempre i comandi all'avvio (guild-only)
    await deployCommands(client.commands);

    // Guild-lock: esce da ogni server diverso da quello autorizzato
    for (const [id, guild] of client.guilds.cache) {
      if (id !== GUILD_ID) {
        console.log(`[GuildLock] Leaving unauthorized guild: ${guild.name} (${id})`);
        try {
          await guild.leave();
        } catch (err) {
          console.error(`[GuildLock] Could not leave guild ${id}:`, err.message);
        }
      }
    }

    client.user.setActivity('this server | /help');
  },
};
