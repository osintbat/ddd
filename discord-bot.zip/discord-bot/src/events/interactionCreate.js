const { Events, ChannelType, PermissionFlagsBits, MessageFlags, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { GUILD_ID, TICKET_CATEGORY_ID } = require('../config');
const { baseEmbed, errorEmbed, successEmbed } = require('../utils/embed');

const TICKET_LABELS = {
  ticket_support: 'Technical Support',
  ticket_purchase: 'Purchase a Plan',
};

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction) {
    // Guild-lock: ignora tutto ciò che non arriva dalla guild autorizzata
    if (interaction.guildId && interaction.guildId !== GUILD_ID) {
      if (interaction.isRepliable()) {
        await interaction
          .reply({
            embeds: [errorEmbed('Not Authorized', 'This bot is not available on this server.')],
            flags: MessageFlags.Ephemeral,
          })
          .catch(() => {});
      }
      return;
    }

    // ---- Slash commands ----
    if (interaction.isChatInputCommand()) {
      const command = interaction.client.commands.get(interaction.commandName);
      if (!command) return;
      try {
        await command.execute(interaction);
      } catch (err) {
        console.error(`[Command Error] /${interaction.commandName}:`, err);
        const payload = {
          embeds: [errorEmbed('Error', 'Something went wrong while executing this command.')],
          flags: MessageFlags.Ephemeral,
        };
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(payload).catch(() => {});
        } else {
          await interaction.reply(payload).catch(() => {});
        }
      }
      return;
    }

    // ---- Ticket dropdown ----
    if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_select_menu') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const category = TICKET_LABELS[interaction.values[0]] || 'Ticket';
      const guild = interaction.guild;
      const safeName = interaction.user.username.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 20) || 'user';
      const channelName = `ticket-${safeName}`;

      // Evita duplicati: se esiste già un ticket aperto per l'utente, reindirizza
      const existing = guild.channels.cache.find(
        (c) => c.name === channelName && c.parentId === TICKET_CATEGORY_ID,
      );
      if (existing) {
        return interaction.editReply({
          embeds: [errorEmbed('Ticket Already Open', `You already have an open ticket: ${existing}`)],
        });
      }

      try {
        const ticketChannel = await guild.channels.create({
          name: channelName,
          type: ChannelType.GuildText,
          parent: TICKET_CATEGORY_ID,
          permissionOverwrites: [
            { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
            {
              id: interaction.user.id,
              allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.ReadMessageHistory,
              ],
            },
            {
              id: guild.members.me.id,
              allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.ManageChannels,
                PermissionFlagsBits.ReadMessageHistory,
              ],
            },
          ],
        });

        const closeRow = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('ticket_close').setLabel('Close Ticket').setStyle(ButtonStyle.Danger),
        );

        await ticketChannel.send({
          content: `${interaction.user}`,
          embeds: [
            baseEmbed({
              title: `${category} Ticket`,
              description:
                `Thank you for opening a ticket, ${interaction.user}.\n\n` +
                `Category: **${category}**\n\n` +
                'Please describe your request in detail. A staff member will be with you shortly.',
              footer: 'Ticket System',
            }),
          ],
          components: [closeRow],
        });

        await interaction.editReply({
          embeds: [successEmbed('Ticket Created', `Your ticket has been created: ${ticketChannel}`)],
        });
      } catch (err) {
        console.error('[Ticket Error]', err);
        await interaction.editReply({
          embeds: [errorEmbed('Error', 'Could not create the ticket channel. Please contact an administrator.')],
        });
      }
      return;
    }

    // ---- Close ticket button ----
    if (interaction.isButton() && interaction.customId === 'ticket_close') {
      const member = interaction.member;
      if (!member.permissions.has(PermissionFlagsBits.ManageChannels)) {
        return interaction.reply({
          embeds: [errorEmbed('Not Allowed', 'Only staff members can close this ticket.')],
          flags: MessageFlags.Ephemeral,
        });
      }

      await interaction.reply({
        embeds: [successEmbed('Closing Ticket', 'This ticket will be deleted in 5 seconds.')],
      });

      setTimeout(() => {
        interaction.channel.delete().catch(() => {});
      }, 5000);
    }
  },
};
