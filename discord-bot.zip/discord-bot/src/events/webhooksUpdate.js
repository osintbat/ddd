const { Events, AuditLogEvent } = require('discord.js');
const { GUILD_ID } = require('../config');
const store = require('../utils/store');
const { punishWebhookCreation } = require('../utils/antinukeActions');

module.exports = {
  name: Events.WebhooksUpdate,
  async execute(channel) {
    const guild = channel.guild;
    if (!guild || guild.id !== GUILD_ID) return;
    if (!store.antinukeEnabled) return;

    try {
      const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.WebhookCreate, limit: 5 });
      const entry = logs.entries.find((e) => Date.now() - e.createdTimestamp < 10000);
      if (!entry) return;

      const creatorId = entry.executor?.id;
      const webhookId = entry.target?.id;
      if (!creatorId || !webhookId) return;

      // Non punire il bot stesso o altri bot legittimi dello staff se necessario
      await punishWebhookCreation(guild, webhookId, creatorId, channel);
    } catch (err) {
      console.error('[Antinuke] webhooksUpdate check failed:', err.message);
    }
  },
};
