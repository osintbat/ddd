const { Events, AuditLogEvent } = require('discord.js');
const { GUILD_ID, ANTINUKE_BOT_WATCH_MS } = require('../config');
const store = require('../utils/store');

module.exports = {
  name: Events.GuildMemberAdd,
  async execute(member) {
    if (member.guild.id !== GUILD_ID) return;
    if (!store.antinukeEnabled) return;
    if (!member.user.bot) return; // ci interessano solo i bot appena invitati

    try {
      // Cerca nell'audit log chi ha invitato/autorizzato questo bot
      const logs = await member.guild.fetchAuditLogs({
        type: AuditLogEvent.BotAdd,
        limit: 5,
      });

      const entry = logs.entries.find((e) => e.target?.id === member.id);
      const inviterId = entry?.executor?.id;

      if (inviterId) {
        store.watchedBots.set(member.id, { inviterId, addedAt: Date.now() });

        // Rimuove il bot dalla watchlist dopo la finestra di osservazione
        setTimeout(() => {
          const entryInMap = store.watchedBots.get(member.id);
          if (entryInMap && Date.now() - entryInMap.addedAt >= ANTINUKE_BOT_WATCH_MS) {
            store.watchedBots.delete(member.id);
          }
        }, ANTINUKE_BOT_WATCH_MS + 1000);
      }
    } catch (err) {
      console.error('[Antinuke] Failed to read audit log on BotAdd:', err.message);
    }
  },
};
