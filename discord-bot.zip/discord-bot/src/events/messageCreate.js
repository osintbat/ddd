const { Events, PermissionFlagsBits } = require('discord.js');
const {
  GUILD_ID,
  ANTISPAM_MESSAGE_LIMIT,
  ANTISPAM_TIME_WINDOW_MS,
  ANTISPAM_TIMEOUT_MS,
} = require('../config');
const store = require('../utils/store');
const { punishNukeAttempt } = require('../utils/antinukeActions');
const { infoEmbed } = require('../utils/embed');

module.exports = {
  name: Events.MessageCreate,
  async execute(message) {
    if (!message.guild || message.guild.id !== GUILD_ID) return;
    if (message.author.id === message.client.user.id) return;

    // ---- ANTINUKE: bot sospetto che invia un messaggio subito dopo essere entrato ----
    if (store.antinukeEnabled && message.author.bot) {
      const watched = store.watchedBots.get(message.author.id);
      if (watched) {
        await punishNukeAttempt(
          message.guild,
          message.author.id,
          watched.inviterId,
          'sending a message right after joining',
        );
      }
      return;
    }

    if (message.author.bot) return;

    // ---- ANTISPAM ----
    const member = message.member;
    if (!member) return;
    if (member.permissions.has(PermissionFlagsBits.Administrator)) return; // gli admin non vengono limitati

    const now = Date.now();
    const timestamps = store.spamTracker.get(message.author.id) || [];
    const recent = timestamps.filter((t) => now - t < ANTISPAM_TIME_WINDOW_MS);
    recent.push(now);
    store.spamTracker.set(message.author.id, recent);

    if (recent.length >= ANTISPAM_MESSAGE_LIMIT) {
      store.spamTracker.set(message.author.id, []); // reset

      try {
        // Elimina gli ultimi messaggi dell'utente in questo canale
        const fetched = await message.channel.messages.fetch({ limit: 20 });
        const toDelete = fetched.filter(
          (m) => m.author.id === message.author.id && now - m.createdTimestamp < ANTISPAM_TIME_WINDOW_MS + 1000,
        );
        await message.channel.bulkDelete(toDelete, true).catch(() => {});
      } catch (err) {
        console.error('[Antispam] Failed to delete messages:', err.message);
      }

      try {
        if (member.moderatable) {
          await member.timeout(ANTISPAM_TIMEOUT_MS, 'Antispam: sending messages too quickly');
          message.channel
            .send({
              embeds: [
                infoEmbed(
                  'Antispam Triggered',
                  `${member} has been timed out for 1 minute for spamming messages.`,
                ),
              ],
            })
            .then((m) => setTimeout(() => m.delete().catch(() => {}), 8000))
            .catch(() => {});
        }
      } catch (err) {
        console.error('[Antispam] Failed to timeout member:', err.message);
      }
    }
  },
};
