const { Events, AuditLogEvent } = require('discord.js');
const { GUILD_ID } = require('../config');
const store = require('../utils/store');
const { punishNukeAttempt } = require('../utils/antinukeActions');

module.exports = {
  name: Events.ChannelCreate,
  async execute(channel) {
    const guild = channel.guild;
    if (!guild || guild.id !== GUILD_ID) return;
    if (!store.antinukeEnabled) return;

    try {
      const logs = await guild.fetchAuditLogs({ type: AuditLogEvent.ChannelCreate, limit: 5 });
      const entry = logs.entries.find((e) => e.target?.id === channel.id);
      const executorId = entry?.executor?.id;
      if (!executorId) return;

      const watched = store.watchedBots.get(executorId);
      if (watched) {
        await punishNukeAttempt(guild, executorId, watched.inviterId, 'creating a channel right after joining');
      }
    } catch (err) {
      console.error('[Antinuke] channelCreate check failed:', err.message);
    }
  },
};
