const { SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const { successEmbed, errorEmbed } = require('../utils/embed');
const store = require('../utils/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('antinuke')
    .setDescription('Enable or disable the antinuke protection system')
    .addStringOption((opt) =>
      opt
        .setName('state')
        .setDescription('Enable or disable protection')
        .setRequired(true)
        .addChoices(
          { name: 'Enable', value: 'enable' },
          { name: 'Disable', value: 'disable' },
        ),
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const state = interaction.options.getString('state');

    if (state === 'enable') {
      store.antinukeEnabled = true;
      return interaction.reply({
        embeds: [
          successEmbed(
            'Antinuke Enabled',
            'Antinuke protection is now **active**.\n\n' +
              '- Any bot that creates a channel or sends a message shortly after joining will be banned, along with the member who invited it.\n' +
              '- Any webhook created by a member will be deleted immediately and that member will be kicked.',
          ),
        ],
        flags: MessageFlags.Ephemeral,
      });
    }

    store.antinukeEnabled = false;
    return interaction.reply({
      embeds: [errorEmbed('Antinuke Disabled', 'Antinuke protection is now **inactive**.')],
      flags: MessageFlags.Ephemeral,
    });
  },
};
