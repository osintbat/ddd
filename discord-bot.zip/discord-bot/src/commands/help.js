const { SlashCommandBuilder, MessageFlags } = require('discord.js');
const { baseEmbed } = require('../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Shows all available commands'),

  async execute(interaction) {
    const embed = baseEmbed({
      title: 'Available Commands',
      description: 'Here is the list of all commands you can use on this server.',
      fields: [
        {
          name: '/help',
          value: 'Shows this help message.',
        },
        {
          name: '/antinuke',
          value:
            'Enables the antinuke protection system. Bans any bot (and the user who invited it) if that bot creates a channel or sends a message shortly after joining. Also removes rogue webhooks and kicks whoever created them.',
        },
        {
          name: '/ticketpanel',
          value:
            'Sends the ticket panel embed with a dropdown menu so members can open a support or purchase ticket.',
        },
      ],
      footer: 'Advanced Security Bot',
    });

    await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
  },
};
