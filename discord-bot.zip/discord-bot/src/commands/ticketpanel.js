const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  MessageFlags,
} = require('discord.js');
const { baseEmbed } = require('../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticketpanel')
    .setDescription('Sends the ticket panel with a category selection menu')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const embed = baseEmbed({
      title: 'Support & Sales Tickets',
      description:
        'Need help or want to purchase a plan? Open a ticket by selecting a category from the menu below.\n\n' +
        '**Technical Support**\nFor bugs, issues, or general questions about our services.\n\n' +
        '**Purchase a Plan**\nTo buy or upgrade one of our available plans.\n\n' +
        'A private channel will be created for you and our staff will assist you as soon as possible.',
      footer: 'Ticket System',
    });

    const menu = new StringSelectMenuBuilder()
      .setCustomId('ticket_select_menu')
      .setPlaceholder('Select a ticket category...')
      .addOptions(
        {
          label: 'Technical Support',
          description: 'Report an issue or ask a technical question',
          value: 'ticket_support',
          emoji: '🛠️',
        },
        {
          label: 'Purchase a Plan',
          description: 'Buy or upgrade a plan',
          value: 'ticket_purchase',
          emoji: '💳',
        },
      );

    const row = new ActionRowBuilder().addComponents(menu);

    await interaction.channel.send({ embeds: [embed], components: [row] });
    await interaction.reply({
      embeds: [baseEmbed({ title: 'Ticket panel sent', description: 'The ticket panel has been posted in this channel.' })],
      flags: MessageFlags.Ephemeral,
    });
  },
};
