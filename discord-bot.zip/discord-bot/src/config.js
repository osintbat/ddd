require('dotenv').config();

module.exports = {
  TOKEN: process.env.DISCORD_TOKEN,
  CLIENT_ID: process.env.CLIENT_ID,
  GUILD_ID: process.env.GUILD_ID || '1537086580815044719',
  TICKET_CATEGORY_ID: process.env.TICKET_CATEGORY_ID || '1537090319332540476',

  // Colore embed richiesto: bianco
  EMBED_COLOR: 0xFFFFFF,

  // Antispam: N messaggi in X millisecondi => elimina + timeout
  ANTISPAM_MESSAGE_LIMIT: 3,
  ANTISPAM_TIME_WINDOW_MS: 3000,
  ANTISPAM_TIMEOUT_MS: 60 * 1000, // 1 minuto

  // Antinuke: finestra di tempo entro la quale un bot appena entrato
  // viene considerato "sospetto" se crea canali o manda messaggi
  ANTINUKE_BOT_WATCH_MS: 5 * 60 * 1000, // 5 minuti
};
