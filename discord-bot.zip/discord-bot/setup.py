#!/usr/bin/env python3
"""
Setup automatico per il bot Discord su Ubuntu 24.04 (VPS).
Copia il progetto in una cartella di destinazione, installa Node.js/dipendenze,
crea il file .env e configura un servizio systemd che avvia il bot in background,
con riavvio automatico ad ogni crash e all'avvio del sistema.

Uso:
    sudo python3 setup.py
"""

import os
import shutil
import subprocess
import sys
import getpass

SERVICE_NAME = "discord-bot"
DEFAULT_DEST = "/opt/discord-bot"


def run(cmd, cwd=None, check=True):
    print(f"$ {cmd}")
    return subprocess.run(cmd, shell=True, cwd=cwd, check=check)


def require_root():
    if os.geteuid() != 0:
        print("Questo script deve essere eseguito con sudo/root: sudo python3 setup.py")
        sys.exit(1)


def ensure_node():
    node_ok = shutil.which("node") is not None
    if node_ok:
        print("[OK] Node.js già presente.")
        return
    print("[Setup] Node.js non trovato, installo Node.js 20 LTS...")
    run("apt-get update -y")
    run("curl -fsSL https://deb.nodesource.com/setup_20.x | bash -")
    run("apt-get install -y nodejs")


def main():
    require_root()

    script_dir = os.path.dirname(os.path.abspath(__file__))

    print("=== Setup Advanced Security Discord Bot ===\n")

    dest = input(f"Cartella di destinazione [{DEFAULT_DEST}]: ").strip() or DEFAULT_DEST
    token = getpass.getpass("Discord Bot Token: ").strip()
    client_id = input("Discord Application (Client) ID: ").strip()
    guild_id = input("Guild ID [1537086580815044719]: ").strip() or "1537086580815044719"
    ticket_category = input("Ticket Category ID [1537090319332540476]: ").strip() or "1537090319332540476"

    run_user = input("Utente linux con cui eseguire il servizio [root]: ").strip() or "root"

    if not token or not client_id:
        print("Token e Client ID sono obbligatori.")
        sys.exit(1)

    # ---- Copia i file del progetto (esclude node_modules/.env se presenti) ----
    print(f"\n[Setup] Copio il progetto in {dest} ...")
    if os.path.abspath(dest) != script_dir:
        os.makedirs(dest, exist_ok=True)
        for item in os.listdir(script_dir):
            if item in ("node_modules", ".env", "__pycache__"):
                continue
            src_path = os.path.join(script_dir, item)
            dst_path = os.path.join(dest, item)
            if os.path.isdir(src_path):
                shutil.copytree(src_path, dst_path, dirs_exist_ok=True)
            else:
                shutil.copy2(src_path, dst_path)

    # ---- Scrive .env ----
    env_path = os.path.join(dest, ".env")
    with open(env_path, "w") as f:
        f.write(f"DISCORD_TOKEN={token}\n")
        f.write(f"CLIENT_ID={client_id}\n")
        f.write(f"GUILD_ID={guild_id}\n")
        f.write(f"TICKET_CATEGORY_ID={ticket_category}\n")
    os.chmod(env_path, 0o600)
    print("[OK] File .env creato.")

    # ---- Node.js + dipendenze ----
    ensure_node()
    print("[Setup] Installo le dipendenze npm...")
    run("npm install --omit=dev", cwd=dest)

    # ---- Permessi ----
    run(f"chown -R {run_user}:{run_user} {dest}")

    # ---- File systemd ----
    node_path = shutil.which("node") or "/usr/bin/node"
    service_content = f"""[Unit]
Description=Advanced Security Discord Bot
After=network.target

[Service]
Type=simple
User={run_user}
WorkingDirectory={dest}
ExecStart={node_path} {dest}/src/index.js
Restart=on-failure
RestartSec=5
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
"""
    service_path = f"/etc/systemd/system/{SERVICE_NAME}.service"
    with open(service_path, "w") as f:
        f.write(service_content)
    print(f"[OK] Service systemd creato in {service_path}")

    # ---- Avvio ----
    run("systemctl daemon-reload")
    run(f"systemctl enable {SERVICE_NAME}")
    run(f"systemctl restart {SERVICE_NAME}")

    print("\n=== Fatto! ===")
    print(f"Il bot gira in background come servizio systemd '{SERVICE_NAME}'.")
    print(f"Stato:   sudo systemctl status {SERVICE_NAME}")
    print(f"Log:     sudo journalctl -u {SERVICE_NAME} -f")
    print(f"Restart: sudo systemctl restart {SERVICE_NAME}   (risincronizza anche i comandi slash)")


if __name__ == "__main__":
    main()
